### The objective of this R script: infer a signaling network between two specified cell types using a step-by-step running fasion.
# System requirements: >= 4 logical cores, >= 8GB memory, >= 10GB disk.
# Timing: ~6h (2.3 GHz 8-Core Intel Core i9, 16 logical cores and 16GB memory)

# There are 10 input parameters for running the CytoTalk algorithm as below.
#' @param species indicating the species from which the scRNA-Seq data are generated. Currently, “Human” and “Mouse” are supported.
#' @param CellTypeA specifying the name of cell type A. Please make sure that the cell type name should be consistent with scRNA-seq data file.
#' @param CellTypeB specifying the name of cell type B. Please make sure that the cell type name should be consistent with scRNA-seq data file.
#' @param GeneFilterCutoff_A indicating the cutoff for removing lowly-expressed genes in the processing of scRNA-seq data of cell type A. The default cutoff value is 0.1, which means that genes expressed in less than 10% of all cells of cell type A are removed.
#' @param GeneFilterCutoff_B indicating the cutoff for removing lowly-expressed genes in the processing of scRNA-seq data of cell type B. The default cutoff value is 0.1, which means that genes expressed in less than 10% of all cells of cell type B are removed.
#' @param BetaUpperLimit indicating the upper limit of the test values of the PCSF objective function parameter β, which is inversely proportional to the total number of genes in a given cell-type pair after removing lowly-expressed genes. Based on preliminary tests, the upper limit of β value is suggested to be 100 (default) if the total number of genes in a given cell-type pair is above 10,000. However, if the total number of genes is below 5000, it is necessary to increase the upper limit of β value to 500.
#' @param Order indicating the order of the neighborhood of the ligand and receptor to extract their-associated pathway from the predicted signaling network between the two cell types.
#' @param InputPath specifying the directory that includes necessary input files for running CytoTalk.
#' @param OutputPath specifying the directory that includes the folder "/IllustratePCSF/" and "/IllustratePathway/" to show the whole predicted network and each ligand-receptor-associated pathway, respectively.
#' @param WorkingPath specifying the directory that includes all CytoTalk functions.


### Customize your inputs and parameters:
rm(list = ls())
species <- "Mouse"
CellTypeA <- "Fibroblasts"
CellTypeB <- "LuminalEpithelialCells"
GeneFilterCutoff_A <- 0.1
GeneFilterCutoff_B <- 0.1
BetaUpperLimit <- 100
Order <- 5

InputPath <- "/YourWorkingDirectory/Input"
#Include files below under the InputPath.
#   "scRNAseq_Fibroblasts/Macrophages/EndothelialCells/.../xxx.csv"
#   "ProteinCodingGenes_Human.txt"
#   "ProteinCodingGenes_Mouse.txt"
#   "LigandReceptor_Human.txt"
#   "LigandReceptor_Mouse.txt"
#   "deter_W4.R" (DO NOT change)
#   "gen_PCSF.py" (DO NOT change)

OutputPath <- "/YourWorkingDirectory/Output"
#The folder "OutputPath/IllustratePCSF/" contains a network topology file "PCSF_edgeSym.sif" and six attribute files that are ready for import into Cytoscape.
#The folder "OutputPath/IllustratePathway/" contains a pathway topology file and six attribute files for each ligand-receptor-associated pathway.

WorkingPath <- "/YourWorkingDirectory/CytoTalk_Function"
setwd(WorkingPath)
#----------------Import functions (DO NOT change code below)-----------------#
source("gen_intracellularNetMat.R")
source("comp_MIcoexp_TypA_WinPara.R")
source("comp_MIcoexp_TypB_WinPara.R")
source("comp_GeneNet_TypA_LinuxPara.R")
source("comp_GeneNet_TypB_LinuxPara.R")
source("comp_NonSelfTalkScore_TypA.R")
source("comp_NonSelfTalkScore_TypB.R")
source("construct_integratedNetwork.R")
source("JobRun_Parallel.R")
source("gen_signalingNetwork.R")
source("gen_signalingPathway.R")
#----------------Import functions (DO NOT change code above)-----------------#



### Run the CytoTalk:
#0) Create the Output folder.
dir.create(OutputPath, showWarnings = FALSE)

#1) Pre-process the scRNA-seq data. ~5min
print("Start running CytoTalk!")
print(Sys.time())
preprocess(species, CellTypeA, CellTypeB, GeneFilterCutoff_A, GeneFilterCutoff_B, InputPath, OutputPath)

#2) Generate mutual information matrix using parallel environment. ~4h depending on the number of single cells and available logical cores.
print(Sys.time())
compMI_TypeA(OutputPath)
print(Sys.time())
compMI_TypeB(OutputPath)

#3) Generate indirect edge-filtered network matrix using parallel environment. ~10min
print(Sys.time())
compGeneNet_TypeA(OutputPath)
print(Sys.time())
compGeneNet_TypeB(OutputPath)

#4) Construct the integrated gene network. ~40min
print(Sys.time())
compNonSelfTalkScore_TypeA(species, CellTypeA, InputPath, OutputPath)
compNonSelfTalkScore_TypeB(species, CellTypeB, InputPath, OutputPath)
constructIntegratedNetwork(species, BetaUpperLimit, InputPath, OutputPath)

#5) Generate background PCSFs based on the integrated gene network. ~20min
print(Sys.time())
JobRunParallel(OutputPath)

#6) Generate the final signaling network between the two cell types. ~25min
print(Sys.time())
genSignalingNetwork(BetaUpperLimit, InputPath, OutputPath)

#7) Extract ligand-receptor-associated pathways from the predicted signaling network between the two cell types.
print(Sys.time())
extractPathway(OutputPath, Order)
print(Sys.time())
print("ALL DONE! CytoTalk has generated output files in the folders: 'OutputPath/IllustratePCSF/' and 'OutputPath/IllustratePathway/'")


