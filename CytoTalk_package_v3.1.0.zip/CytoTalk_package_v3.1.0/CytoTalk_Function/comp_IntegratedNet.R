compIntegratedNet <- function(OutputPath) {
  
  #-Generate integrated network for PCSF.
  MI_topNet_TypATypB_File <- paste(OutputPath, "/MI_topNet_TypATypB.RData", sep = "")
  CrosstalkNet_TypATypB_File <- paste(OutputPath, "/CrosstalkNet_TypATypB.RData", sep = "")
  ArtiEdge_File <- paste(OutputPath, "/ArtiEdge.RData", sep = "")
  load(MI_topNet_TypATypB_File)
  load(CrosstalkNet_TypATypB_File)
  load(ArtiEdge_File)
  
  integratedNet_EdgeID <- rbind(MiList_genePair_TypATypB, crosstalkNet_id, artiEdge_id)
  integratedNet_EdgeID <- integratedNet_EdgeID - 1  #-Python is 0-based indexing.
  integratedNet_EdgeValue_common <- c(MiList_value_TypATypB, crosstalkNet_Sco)  #-need add artiEdgeCost.
  
  minValue <- min(integratedNet_EdgeValue_common)
  maxValue <- max(integratedNet_EdgeValue_common)
  integratedNet_EdgeValue_common <- (integratedNet_EdgeValue_common - minValue) / (maxValue - minValue)
  integratedNet_EdgeCost_common <- 1 - integratedNet_EdgeValue_common
  integratedNet_EdgeCost_common <- as.matrix(integratedNet_EdgeCost_common)
  
  integratedNet_GeneSym <- rbind(MiList_geneSym_TypATypB, as.matrix(artiNodeSym))
  integratedNet_GenePrize_initial <- rbind(MiList_genePrize_TypATypB, as.matrix(artiNodePrize))  #-need multiply beta.
  
  IntegratedNet_TypATypB_ID_File <- paste(OutputPath, "/IntegratedNet_TypATypB_ID.RData", sep = "")
  save(integratedNet_EdgeID, integratedNet_EdgeCost_common, integratedNet_GeneSym, integratedNet_GenePrize_initial, file = IntegratedNet_TypATypB_ID_File)

}


