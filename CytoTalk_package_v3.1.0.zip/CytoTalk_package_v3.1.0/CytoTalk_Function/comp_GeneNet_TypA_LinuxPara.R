compGeneNet_TypeA <- function(OutputPath) {
  
  print("(3/7) Removing indirect edges for cell type A...(around 5 min)")
  
  library(doParallel)
  #-setup parallel environment.
  no_cores <- detectCores() - 2 #to be safe from any RStudio crashing, use two less cores.
  Sys.setenv("OMP_NUM_THREADS" = no_cores)
  
  #load Tumo mutual information matrix.
  MutualInfo_TypA_Para_File <- paste(OutputPath, "/MutualInfo_TypA_Para.txt", sep = "")
  MIadj_Tumo <- read.table(MutualInfo_TypA_Para_File, header = TRUE, sep = " ") #-checked.
  
  #set diagonal values to zeros to avoid self-cycles.
  totalGene <- 1:nrow(MIadj_Tumo)
  for (i in totalGene) {
    #---------progress bar-------------#
    #cat("Gene:", i, "\n"); #Very fast.
    #----------------------------------#
    
    MIadj_Tumo[i,i] <- 0
    
  }
  
  #remove indirect edges.(should set environment variable: export OMP_NUM_THREADS=n)
  library(parmigene)
  #Sys.time()
  MIadj_Tumo <- as.matrix(MIadj_Tumo)
  GN_Tumo <- aracne.m(MIadj_Tumo, 0.15) 
  #Sys.time()
  
  IntracellularNetwork_TypeA_File <- paste(OutputPath, "/IntracellularNetwork_TypeA.txt", sep = "")
  write.table(GN_Tumo, IntracellularNetwork_TypeA_File, quote = FALSE) 
  #Sys.time()

}


