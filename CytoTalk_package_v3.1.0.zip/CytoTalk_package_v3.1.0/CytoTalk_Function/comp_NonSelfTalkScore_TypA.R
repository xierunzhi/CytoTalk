compNonSelfTalkScore_TypeA <- function(species, CellTypeA, InputPath, OutputPath) {
  
  print("(4/7) Constructing the integrated gene network--Computation of NonSelfTalk score of TypeA")
  
  ##--compute NonSelfTalk score of TypA part for all known ligand-receptor pairs.
  library(entropy)
  
  NonSelfTalkSym_Tumo <- vector()  #-initiated as empty.
  NonSelfTalkSco_Tumo <- vector()
  
  if (species == "Human") {
    
    LigandReceptor_Human_File <- paste(InputPath, "/LigandReceptor_Human.txt", sep = "")
    LRpair <- read.table(LigandReceptor_Human_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
    
  }
  
  if (species == "Mouse") {
    
    LigandReceptor_Mouse_File <- paste(InputPath, "/LigandReceptor_Mouse.txt", sep = "")
    LRpair <- read.table(LigandReceptor_Mouse_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
    
  }
  
  
  #load Tumo expression matrix
  TypA_file <- paste(InputPath, "/scRNAseq_", CellTypeA, ".csv", sep = "")
  
  TumoExp0 <- read.csv(TypA_file) #now row names as first column.
  TumoExp <- TumoExp0[, -1] #remove the first column.
  rownames(TumoExp) <- TumoExp0[, 1]  #set first column as row names.
  
  totalNum <- 1:nrow(LRpair)
  for (i in totalNum) {
    #---------progress bar-------------#
    #cat("LRpair:", i, "\n");
    #----------------------------------#
    
    ind_1 <- match(LRpair[i, 1], row.names(TumoExp))
    
    if (!is.na(ind_1)) {
      ind_2 <- match(LRpair[i, 2], row.names(TumoExp))
      
      if (!is.na(ind_2)) {
        
        Tumo_exp_g1 <- TumoExp[ind_1,]  #-checked.
        Tumo_exp_g2 <- TumoExp[ind_2,] 
        
        #-number of bins is set to sqrt(number of samples)--WGCNA mannual.
        #-compute mutual information in Tumo.
        
        #-Here need to add noise to all-zero-genes.
        Tumo_exp_g1_value <- as.numeric(Tumo_exp_g1)
        Tumo_exp_g2_value <- as.numeric(Tumo_exp_g2)
        
        if (all(Tumo_exp_g1_value==0)) {
          randCell_1 <- sample(1:length(Tumo_exp_g1_value), 1)
          Tumo_exp_g1_value[randCell_1] <- 1E-20
        }
        
        if (all(Tumo_exp_g2_value==0)) {
          randCell_2 <- sample(1:length(Tumo_exp_g2_value), 1)
          Tumo_exp_g2_value[randCell_2] <- 1E-20
        }
        
        Tumo_table <- discretize2d(Tumo_exp_g1_value, Tumo_exp_g2_value, numBins1 = sqrt(ncol(Tumo_exp_g1)), numBins2 = sqrt(ncol(Tumo_exp_g2)))
        Tumo_H1 <- entropy(rowSums(Tumo_table), method = "MM")  #compute marginal entropies.
        Tumo_H2 <- entropy(colSums(Tumo_table), method = "MM")
        Tumo_H12 <- entropy(Tumo_table, method = "MM")
        Tumo_MI <- Tumo_H1+Tumo_H2-Tumo_H12
        
        normFactor <- min(c(Tumo_H1,Tumo_H2))
        Tumo_MI_dist <- -log10(Tumo_MI/normFactor)
        
        NonSelfTalkSym_Tumo <- rbind(NonSelfTalkSym_Tumo, LRpair[i,])
        NonSelfTalkSco_Tumo <- rbind(NonSelfTalkSco_Tumo, Tumo_MI_dist) 
        
      }
    }
    
  }  #-end of For loop.
  
  NonSelfTalkSym_TypA_File <- paste(OutputPath, "/NonSelfTalkSym_TypA.txt", sep = "")
  NonSelfTalkSco_TypA_File <- paste(OutputPath, "/NonSelfTalkSco_TypA.txt", sep = "")
  write.table(NonSelfTalkSym_Tumo, NonSelfTalkSym_TypA_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)   #-checked.
  write.table(NonSelfTalkSco_Tumo, NonSelfTalkSco_TypA_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)   #-checked.
  
}


