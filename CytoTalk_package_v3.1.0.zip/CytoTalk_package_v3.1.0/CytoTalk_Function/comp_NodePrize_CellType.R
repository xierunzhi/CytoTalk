genExpAll <- function(InputPath, OutputPath) {
    
    #-find the file names of all cell types.
    allExpFile <- list.files(path = InputPath, pattern = "scRNAseq_")
    allExpVector <- list()
    for (i in 1:length(allExpFile)) {            #~35s.
        fileName <- paste(InputPath, "/", allExpFile[i], sep = "")
        
        Exp_rmRep_dm0 <- read.csv(fileName) #now row names as first column.
        Exp_rmRep_dm <- Exp_rmRep_dm0[, -1] #remove the first column.
        rownames(Exp_rmRep_dm) <- Exp_rmRep_dm0[, 1]  #set first column as row names.
        rm(Exp_rmRep_dm0)
        
        allExpVector[[i]] <- Exp_rmRep_dm
        rm(Exp_rmRep_dm)
        
    } #end of for.
    
    Exp_allCSV_File <- paste(OutputPath, "/Exp_allCSV.RData", sep = "")
    save(allExpFile, allExpVector, file = Exp_allCSV_File)
    
} #end of function.


genExpAllNoLog <- function(OutputPath) {
    
    #-convert back to count-based data. Currently, Exp=ln(count+1).
    Exp_allCSV_File <- paste(OutputPath, "/Exp_allCSV.RData", sep = "")
    load(Exp_allCSV_File)
    allExpVector_NoLog <- list()
    for (i in 1:length(allExpVector)) {
        allExpVector_NoLog[[i]] <- expm1(allExpVector[[i]])  #-checked.
        
    }
    
    Exp_allCSV_NoLog_File <- paste(OutputPath, "/Exp_allCSV_NoLog.RData", sep = "")
    save(allExpFile, allExpVector_NoLog, file = Exp_allCSV_NoLog_File)
    
}  #end of function.


compPEM <- function(OutputPath) {
    
    #-----------------------------Compute PEM score------------------------------#
    Exp_allCSV_NoLog_File <- paste(OutputPath, "/Exp_allCSV_NoLog.RData", sep = "")
    load(Exp_allCSV_NoLog_File)
    same_rowname <- rownames(allExpVector_NoLog[[1]])
    
    Exp_tpmMean <- list()
    Exp_tpmSum <- list()
    for (i in 1:length(allExpVector_NoLog)) {
        Exp_tpmMean[[i]] <- rowMeans(allExpVector_NoLog[[i]])  #find average value for each row (gene).
        Exp_tpmSum[[i]] <- sum(Exp_tpmMean[[i]])
        
    }
    
    #--Compute gene summary and dataset summary used for PEM score.
    geneMatrix <- Exp_tpmMean[[1]]  #initialization.
    datasetSum <- Exp_tpmSum[[1]]
    for (i in 2:length(Exp_tpmMean)) {  # start from 2.
        
        geneMatrix <- cbind(geneMatrix, Exp_tpmMean[[i]])
        datasetSum <- datasetSum + Exp_tpmSum[[i]]
        
    }
    geneSum <- rowSums(geneMatrix)
    
    #--Compute cell-type-specificity.
    typeSpecific <- list()
    for (kk in 1:length(Exp_tpmMean)) {  #these two embeded loops are very fast.
        typeSpecific[[kk]] <- vector()  #initialization
        
        for (i in 1:length(same_rowname)) {
            e <- geneSum[i] * (Exp_tpmSum[[kk]]/datasetSum)
            typeSpecific[[kk]][i] <- log10(Exp_tpmMean[[kk]][i]/e)
            
        }
        
    }
    
    GeneCellTypeSpecific_File <- paste(OutputPath, "/GeneCellTypeSpecific.RData", sep = "")
    save(same_rowname, allExpFile, Exp_tpmMean, Exp_tpmSum, geneSum, datasetSum, typeSpecific, file = GeneCellTypeSpecific_File)
    
}  #end of function.


compNodePrize_CellType <- function(InputPath, OutputPath) {
    
    genExpAll(InputPath, OutputPath)
    genExpAllNoLog(OutputPath)
    compPEM(OutputPath)
    
}


