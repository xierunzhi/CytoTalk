genSignalingNetwork <- function(BetaUpperLimit, InputPath, OutputPath) {
  
  print("(6/7) Generating the final signaling network between the two cell types...(around 25 min)")
  
  #--Summarize all PCSFs.
  source("gen_summaryPCSF.R")
  genSummaryPCSF(BetaUpperLimit, InputPath, OutputPath)
  
  #--Select the most robust PCSF from the background PCSFs.
  source("gen_robustPCSF.R")
  genRobustPCSF(OutputPath)    #~25min
  
  #--Generate files ready for import into Cytoscape.
  source("gen_CytoFileFun.R")
  genCytoFile(OutputPath)

}


