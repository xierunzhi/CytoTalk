constructIntegratedNetwork <- function(species, BetaUpperLimit, InputPath, OutputPath) {
  
  print("(4/7) Constructing the integrated gene network...(around 40 min and need 10G space)")
  
  #--Process two intracellular networks based on matrices generated in the Step1.
  source("gen_2intracellularNet.R")
  gen2intracellularNet(OutputPath)
  
  #-----Compute node prize based on PEM score and Relevance coefficient---------------------#
  source("comp_NodePrize_CellType.R")
  compNodePrize_CellType(InputPath, OutputPath)
  
  source("comp_NodePrize_RWR.R")
  compNodePrize_RWR(species, InputPath, OutputPath)  #40min
  
  source("comp_NodePrize_Combine.R")
  compNodePrize_Combine(OutputPath)
  #-------------------Gene Node Prize Done!!!-----------------------#
  
  #------Compute crosstalk score based on non-self-talk score---------#
  source("comp_Crosstalk_specific.R")
  compCrosstalk_specific(OutputPath)
  #-----------------------Crosstalk Score Done!!!---------------------#
  
  #-------------Below for network analysis--------------------------#
  source("comp_topNet_TypA.R")
  compNetCostPrize_TypeA(OutputPath)
  
  source("comp_topNet_TypATypB.R")
  compNetCostPrize_TypeATypeB(OutputPath)
  
  source("comp_CrosstalkNet.R")
  compCrosstalkNet(OutputPath)
  
  source("comp_ArtiNet.R")  #-artiNode is connected to all genes of the integrated networks.
  compArtiNet(OutputPath)
  
  source("comp_IntegratedNet.R")
  compIntegratedNet(OutputPath)
  
  source("write_IntegratedNet.R")
  writeIntegratedNet(OutputPath)
  
  source("gen_diffOmgBt_Parallel_v2.R")  #-Parallelly generate different folders for different parameter (omega and beta) settings for parallel PCSF running.
  genDiffOmgBt_Parallel(BetaUpperLimit, InputPath, OutputPath)
  
}


