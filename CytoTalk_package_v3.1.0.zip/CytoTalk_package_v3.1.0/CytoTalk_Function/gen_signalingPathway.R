extractNeighborhood <- function(order, geneSym, TypA_edgeSym, TypA_edgeCost, edgeTypeCode) {
    
    intraEdgeSym <- vector()
    intraEdgeCost <- vector()
    intraEdgeCellType <- vector()
    
    for (m in 1:order) {
        
        if (m == 1) {
            newGeneSet_preOrder <- geneSym  #initiation.
            
        } else {
            newGeneSet_preOrder <- newGeneSet_CurrentOrder
        }
        
        newGeneSet_CurrentOrder <- vector()
        
        if (length(newGeneSet_preOrder) > 0 && length(TypA_edgeCost) > 0) {  #enter only if there are new intracellular nodes and there are still intracelular edges left.
            
            for (k in 1:length(newGeneSet_preOrder)) {
                
                #first, check the data type of "TypA_edgeSym".
                if (length(TypA_edgeCost) == 1) { #it's a very special case.
                    TypA_edgeSym <- as.vector(TypA_edgeSym) #reset
                    TypA_edgeSym <- t(as.matrix(TypA_edgeSym))
                }

                #then, find neighbors.
                indTypA_1col <- which(TypA_edgeSym[, 1] == newGeneSet_preOrder[k])
                if (length(indTypA_1col) > 0) {
                    newGeneSet_1 <- TypA_edgeSym[indTypA_1col, 2]  #extract neighbors.
                    
                } else {
                    newGeneSet_1 <- vector()
                    
                }
                
                indTypA_2col <- which(TypA_edgeSym[, 2] == newGeneSet_preOrder[k])
                if (length(indTypA_2col) > 0) {
                    newGeneSet_2 <- TypA_edgeSym[indTypA_2col, 1]  #extract neighbors.
                    
                } else {
                    newGeneSet_2 <- vector()
                    
                }
                
                newGeneSet_CurrentOrder <- unique(c(newGeneSet_CurrentOrder, newGeneSet_1, newGeneSet_2))
                
                intraEdgeInd <- unique(c(indTypA_1col, indTypA_2col))
                if (length(intraEdgeInd) > 0) {
                    intraEdgeSym <- rbind(intraEdgeSym, TypA_edgeSym[intraEdgeInd,])
                    intraEdgeCost <- c(intraEdgeCost, TypA_edgeCost[intraEdgeInd])
                    intraEdgeCellType <- c(intraEdgeCellType, rep(edgeTypeCode, length(intraEdgeInd)))
                    
                    #after recording, delete these edges from intracellular subnetwork.
                    TypA_edgeSym <- TypA_edgeSym[-intraEdgeInd,]
                    TypA_edgeCost <- TypA_edgeCost[-intraEdgeInd]
                    
                }
                
            } #end of k (preOrder)
            
        } #end of if (newGeneSet_preOrder)
        
    }  #end of m (order)
    
    result <- list(intraEdgeSym=intraEdgeSym, intraEdgeCost=intraEdgeCost, intraEdgeCellType=intraEdgeCellType)
    return(result)
    
} #end of function.


genPathwayCytoFile <- function(OutputPath, InnerFolderName, pathway_edgeSym, pathway_edgeCost, pathway_edgeCellType, PCSF_nodeSym, PCSF_geneExp, PCSF_geneCellType, PCSF_genePrize, PCSF_geneRealName) {
    
    #---------Extract gene expression and gene cell type of the given pathway.
    pathway_nodeSym <- unique(c(pathway_edgeSym[, 1], pathway_edgeSym[, 2]))
    pathway_geneExp <- matrix(data = 0L, nrow = length(pathway_nodeSym), ncol = 1)
    pathway_geneCellType <- matrix(data = 0L, nrow = length(pathway_nodeSym), ncol = 1)   #-"1" as TypA; "2" as TypB.
    pathway_genePrize <- matrix(data = 0L, nrow = length(pathway_nodeSym), ncol = 1)
    pathway_geneRealName <- matrix(data = NA, nrow = length(pathway_nodeSym), ncol = 1)
    for (i in 1:length(pathway_nodeSym)) {
        
        ind <- which(PCSF_nodeSym == pathway_nodeSym[i])
        pathway_geneExp[i] <- PCSF_geneExp[ind]
        pathway_geneCellType[i] <- PCSF_geneCellType[ind]
        pathway_genePrize[i] <- PCSF_genePrize[ind]
        pathway_geneRealName[i] <- PCSF_geneRealName[ind]

    } #end of for.
    
    #---------------------------------------Generate files for Cytoscape to show pathways------------------------------------------#
    #-format the gene symbol to replace "TypA" and "TypB" by real cell type names.
    CellTypeName_File <- paste(OutputPath, "/CellTypeName.RData", sep = "")
    load(CellTypeName_File)
    
    for (p in 1:nrow(pathway_edgeSym)) {
        for (q in 1:ncol(pathway_edgeSym)) {
            
            if (substr(pathway_edgeSym[p, q], nchar(pathway_edgeSym[p, q])-3, nchar(pathway_edgeSym[p, q])) == "TypA") {
                
                pathway_edgeSym[p, q] <- paste(c(substr(pathway_edgeSym[p, q], 1, nchar(pathway_edgeSym[p, q])-4), CellTypeA), collapse = '')
                
            } else if (substr(pathway_edgeSym[p, q], nchar(pathway_edgeSym[p, q])-3, nchar(pathway_edgeSym[p, q])) == "TypB") {
                
                pathway_edgeSym[p, q] <- paste(c(substr(pathway_edgeSym[p, q], 1, nchar(pathway_edgeSym[p, q])-4), CellTypeB), collapse = '')
                
            }
            
        }
    }
    
    for (kk in 1:length(pathway_nodeSym)) {
        
        if (substr(pathway_nodeSym[kk], nchar(pathway_nodeSym[kk])-3, nchar(pathway_nodeSym[kk])) == "TypA") {
            
            pathway_nodeSym[kk] <- paste(c(substr(pathway_nodeSym[kk], 1, nchar(pathway_nodeSym[kk])-4), CellTypeA), collapse = '')
            
        } else if (substr(pathway_nodeSym[kk], nchar(pathway_nodeSym[kk])-3, nchar(pathway_nodeSym[kk])) == "TypB") {
            
            pathway_nodeSym[kk] <- paste(c(substr(pathway_nodeSym[kk], 1, nchar(pathway_nodeSym[kk])-4), CellTypeB), collapse = '')
            
        }
        
    }

    #-create a sub-folder for pathway-related Cytoscape files.
    endInd <- nrow(pathway_edgeSym)
    LRname <- paste(c("(", pathway_edgeSym[endInd, 1], ")-(", pathway_edgeSym[endInd, 2], ")"), collapse = '')
    SubFolderName <- paste(c(InnerFolderName, LRname, "/"), collapse = '')
    dir.create(SubFolderName, showWarnings = FALSE)
    
    # pathway topology file.
    addCol <- matrix(data = "pp", nrow = nrow(pathway_edgeSym), ncol = 1)
    pathway_edgeSym_modified1 <- cbind(pathway_edgeSym[, 1], addCol, pathway_edgeSym[, 2])
    pathway_edgeSym_File <- paste(SubFolderName, "Pathway_edgeSym.sif", sep = "")
    write.table(pathway_edgeSym_modified1, pathway_edgeSym_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)
    
    # pathway edge cost file.
    pathway_edgeSym_attr <- matrix(data = NA, nrow = nrow(pathway_edgeSym), ncol = 1)
    for (i in 1:nrow(pathway_edgeSym)) {
        
        pathway_edgeSym_attr[i] <- paste(c(pathway_edgeSym[i, 1], "(pp)", pathway_edgeSym[i, 2]), collapse = ' ')
    }
    pathway_edgeSym_modified2 <- cbind(pathway_edgeSym_attr, pathway_edgeCost)
    colnames(pathway_edgeSym_modified2) <- c("EdgeSym", "EdgeCost")
    pathway_edgeCost_File <- paste(SubFolderName, "Pathway_edgeCost.txt", sep = "")
    write.table(pathway_edgeSym_modified2, pathway_edgeCost_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # pathway edge cell type file.
    pathway_edgeSym_modified3 <- cbind(pathway_edgeSym_attr, pathway_edgeCellType)
    colnames(pathway_edgeSym_modified3) <- c("EdgeSym", "EdgeCellType")
    pathway_edgeCellType_File <- paste(SubFolderName, "Pathway_edgeCellType.txt", sep = "")
    write.table(pathway_edgeSym_modified3, pathway_edgeCellType_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # pathway gene node expression file.
    pathway_nodeSym_modified1 <- cbind(pathway_nodeSym, pathway_geneExp)
    colnames(pathway_nodeSym_modified1) <- c("GeneSym", "GeneExp")
    pathway_geneExp_File <- paste(SubFolderName, "Pathway_geneExp.txt", sep = "")
    write.table(pathway_nodeSym_modified1, pathway_geneExp_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # pathway gene node cell type file.
    pathway_nodeSym_modified2 <- cbind(pathway_nodeSym, pathway_geneCellType)
    colnames(pathway_nodeSym_modified2) <- c("GeneSym", "GeneCellType")
    pathway_geneCellType_File <- paste(SubFolderName, "Pathway_geneCellType.txt", sep = "")
    write.table(pathway_nodeSym_modified2, pathway_geneCellType_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # gene node prize file.
    pathway_nodeSym_modified3 <- cbind(pathway_nodeSym, pathway_genePrize)
    colnames(pathway_nodeSym_modified3) <- c("GeneSym", "GenePrize")
    pathway_genePrize_File <- paste(SubFolderName, "Pathway_genePrize.txt", sep = "")
    write.table(pathway_nodeSym_modified3, pathway_genePrize_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # gene node real name file.
    pathway_nodeSym_modified4 <- cbind(pathway_nodeSym, pathway_geneRealName)
    colnames(pathway_nodeSym_modified4) <- c("GeneSym", "GeneRealName")
    pathway_geneRealName_File <- paste(SubFolderName, "Pathway_geneRealName.txt", sep = "")
    write.table(pathway_nodeSym_modified4, pathway_geneRealName_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)

} #end of function.


extractPathway <- function(OutputPath, order) {
    
    print("(7/7) Generating each ligand-receptor-associated pathway between the two cell types...")
    
    if (order < 1) {
        
        print("Wrong specified order. Please specify an integer no less than 1.")
        
    } else {
        
        pcsf_resultCyto_File <- paste(OutputPath, "/pcsf_resultCyto.RData", sep = "")
        load(pcsf_resultCyto_File)
        
        #---------Divide the whole network into two intracellular parts.
        TypA_edgeInd <- which(PCSF_edgeCellType == 1)
        TypA_edgeSym <- PCSF_edgeSym[TypA_edgeInd,]
        TypA_edgeCost <- PCSF_edgeCost[TypA_edgeInd,]
        
        TypB_edgeInd <- which(PCSF_edgeCellType == 2)
        TypB_edgeSym <- PCSF_edgeSym[TypB_edgeInd,]
        TypB_edgeCost <- PCSF_edgeCost[TypB_edgeInd,]
        
        crosstalk_edgeInd <- which(PCSF_edgeCellType == 3)
        crosstalk_edgeSym <- PCSF_edgeSym[crosstalk_edgeInd,]
        crosstalk_edgeCost <- PCSF_edgeCost[crosstalk_edgeInd,]
        
        #---------Extract specificied order of neighborhood for each ligand-receptor pair as its associated pathway.
        for (i in 1:nrow(crosstalk_edgeSym)) {
            
            for (j in 1:ncol(crosstalk_edgeSym)) {
                
                geneSym <- crosstalk_edgeSym[i, j]
                if (substr(geneSym, nchar(geneSym)-5, nchar(geneSym)) == "__TypA") {  #either TypA or TypB.
                    
                    edgeTypeCode <- 1
                    TypA_edgeTab <- extractNeighborhood(order, geneSym, TypA_edgeSym, TypA_edgeCost, edgeTypeCode)
                    
                } else {
                    
                    edgeTypeCode <- 2
                    TypB_edgeTab <- extractNeighborhood(order, geneSym, TypB_edgeSym, TypB_edgeCost, edgeTypeCode)
                    
                }
                
            } #end of j (ncol)
            
            #-combine two intracellular sub-pathways and a crosstalk edge to construct a complete pathway.
            pathway_edgeSym <- rbind(TypA_edgeTab$intraEdgeSym, TypB_edgeTab$intraEdgeSym, crosstalk_edgeSym[i,])
            pathway_edgeCost <- c(TypA_edgeTab$intraEdgeCost, TypB_edgeTab$intraEdgeCost, crosstalk_edgeCost[i])
            pathway_edgeCellType <- c(TypA_edgeTab$intraEdgeCellType, TypB_edgeTab$intraEdgeCellType, 3)
            
            #----Write the pathway into Cytoscape files including edge and node attributes.
            #-create a pathway folder.
            FolderName <- paste(c(OutputPath, "/IllustratePathway/"), collapse = '')
            dir.create(FolderName, showWarnings = FALSE)
            InnerFolderName <- paste(c(OutputPath, "/IllustratePathway/", order, "_OrderNeighborhood/"), collapse = '')
            dir.create(InnerFolderName, showWarnings = FALSE)
            genPathwayCytoFile(OutputPath, InnerFolderName, pathway_edgeSym, pathway_edgeCost, pathway_edgeCellType, PCSF_nodeSym, PCSF_geneExp, PCSF_geneCellType, PCSF_genePrize, PCSF_geneRealName)
            
        } #end of i (nrow)

    } #end of else.
    
}  #end of function.


