importTypeA <- function(OutputPath) {
    
    #----Import TypA mutual info and indirect edge-filtered network----------------#
    Exp_cleaned_2_File <- paste(OutputPath, "/Exp_cleaned_2.RData", sep = "")
    load(Exp_cleaned_2_File)
    
    IntracellularNetwork_TypeA_File <- paste(OutputPath, "/IntracellularNetwork_TypeA.txt", sep = "")
    MiMatrix_TypA <- read.table(IntracellularNetwork_TypeA_File, header = TRUE, sep = " ", check.names = FALSE, stringsAsFactors = FALSE)
    RowNames_TypA <- rownames(TypAExp_rmRep_dmNew)
    
    #-make it to list format.
    MiMatrix_TypA_sum <- rowSums(MiMatrix_TypA) #add up for each row.
    isolatedNode_fromRow <- which(MiMatrix_TypA_sum == 0, arr.ind = TRUE)  #there is no edge associated with this node, that is isolated node.
    
    if (length(isolatedNode_fromRow) > 0) {
        print("The intracellular network construction for cell type A is wrong!")
    }
    
    if (length(unique(RowNames_TypA)) == length(RowNames_TypA)) {  #-make sure RowNames is unique.
        correctFlag <- 1
    } else {
        correctFlag <- 0
    }
    
    MiList_genePair_TypA <- which(MiMatrix_TypA != 0, arr.ind = TRUE)
    MiList_value_TypA <- MiMatrix_TypA[MiList_genePair_TypA]
    MiList_genePair_TypA <- t(apply(MiList_genePair_TypA, 1, sort))  #-sort each row for convenient comparison in the future.
    
    #only retain half of the matrix due to matrix symmetric.
    uniqRowInd <- which(!duplicated(MiList_genePair_TypA))
    MiList_genePair_TypA <- MiList_genePair_TypA[uniqRowInd,]
    MiList_value_TypA <- MiList_value_TypA[uniqRowInd]
    
    MI_TypA_File <- paste(OutputPath, "/MI_TypA.RData", sep = "")
    save(MiMatrix_TypA, RowNames_TypA, MiList_value_TypA, MiList_genePair_TypA, correctFlag, file = MI_TypA_File)
    #-----------------------TypA done!
    
} #end of function.


importTypeB <- function(OutputPath) {
    
    #----Import TypB mutual info and indirect edge-filtered network---------------#
    Exp_cleaned_4_File <- paste(OutputPath, "/Exp_cleaned_4.RData", sep = "")
    load(Exp_cleaned_4_File)
    
    IntracellularNetwork_TypeB_File <- paste(OutputPath, "/IntracellularNetwork_TypeB.txt", sep = "")
    MiMatrix_TypB <- read.table(IntracellularNetwork_TypeB_File, header = TRUE, sep = " ", check.names = FALSE, stringsAsFactors = FALSE)
    RowNames_TypB <- rownames(TypBExp_rmRep_dmNew)
    
    #-make it to list format.
    MiMatrix_TypB_sum <- rowSums(MiMatrix_TypB) #add up for each row.
    isolatedNode_fromRow <- which(MiMatrix_TypB_sum == 0, arr.ind = TRUE)  #there is no edge associated with this node, that is isolated node.
    
    if (length(isolatedNode_fromRow) > 0) {
        print("The intracellular network construction for cell type B is wrong!")
    }
    
    if (length(unique(RowNames_TypB)) == length(RowNames_TypB)) {  #-make sure RowNames is unique.
        correctFlag <- 1
    } else {
        correctFlag <- 0
    }
    
    MiList_genePair_TypB <- which(MiMatrix_TypB != 0, arr.ind = TRUE)
    MiList_value_TypB <- MiMatrix_TypB[MiList_genePair_TypB]
    MiList_genePair_TypB <- t(apply(MiList_genePair_TypB, 1, sort))  #-sort each row for convenient comparison in the future.
    
    #only retain half of the matrix due to matrix symmetric.
    uniqRowInd <- which(!duplicated(MiList_genePair_TypB))
    MiList_genePair_TypB <- MiList_genePair_TypB[uniqRowInd,]
    MiList_value_TypB <- MiList_value_TypB[uniqRowInd]
    
    MI_TypB_File <- paste(OutputPath, "/MI_TypB.RData", sep = "")
    save(MiMatrix_TypB, RowNames_TypB, MiList_value_TypB, MiList_genePair_TypB, correctFlag, file = MI_TypB_File)
    #-------------------------TypB done!

}  #end of function.


gen2intracellularNet <- function(OutputPath) {
    
    importTypeA(OutputPath)
    importTypeB(OutputPath)
    
}


