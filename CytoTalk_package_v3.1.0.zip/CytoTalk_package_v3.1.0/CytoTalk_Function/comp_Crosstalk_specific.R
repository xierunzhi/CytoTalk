compCrosstalk_specific <- function(OutputPath) {
    
    #-------------------------Compute crosstalk score-----------------------#
    #-import non-self-talk score in TypB.
    NonSelfTalkSym_TypB_File <- paste(OutputPath, "/NonSelfTalkSym_TypB.txt", sep = "")
    LRpairSym_TypB <- read.table(NonSelfTalkSym_TypB_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
    
    NonSelfTalkSco_TypB_File <- paste(OutputPath, "/NonSelfTalkSco_TypB.txt", sep = "")
    NonSelfTalkSco_TypB <- read.table(NonSelfTalkSco_TypB_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
    negativeInd <- which(NonSelfTalkSco_TypB < 0)
    NonSelfTalkSco_TypB$V1[negativeInd] <- 0
    
    nanInd <- which(is.na(NonSelfTalkSco_TypB))
    if (length(nanInd) != 0) {
        NonSelfTalkSco_TypB$V1[nanInd] <- 0
        
    }
    
    
    #-import non-self-talk score in TypA.
    NonSelfTalkSym_TypA_File <- paste(OutputPath, "/NonSelfTalkSym_TypA.txt", sep = "")
    LRpairSym_TypA <- read.table(NonSelfTalkSym_TypA_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
    
    NonSelfTalkSco_TypA_File <- paste(OutputPath, "/NonSelfTalkSco_TypA.txt", sep = "")
    NonSelfTalkSco_TypA <- read.table(NonSelfTalkSco_TypA_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
    negativeInd <- which(NonSelfTalkSco_TypA < 0)
    NonSelfTalkSco_TypA$V1[negativeInd] <- 0
    
    nanInd <- which(is.na(NonSelfTalkSco_TypA))
    if (length(nanInd) != 0) {
        NonSelfTalkSco_TypA$V1[nanInd] <- 0
        
    }
    
    
    GeneCellTypeSpecific_File <- paste(OutputPath, "/GeneCellTypeSpecific.RData", sep = "")
    load(GeneCellTypeSpecific_File)
    
    CellTypeName_File <- paste(OutputPath, "/CellTypeName.RData", sep = "")
    load(CellTypeName_File)
    
    for (s in 1:length(allExpFile)) {
        if (grepl(CellTypeA, allExpFile[s], fixed = TRUE)) {
            TypA_PEM_ind <- s
            
        }
        if (grepl(CellTypeB, allExpFile[s], fixed = TRUE)) {
            TypB_PEM_ind <- s
            
        }
        
    }
    
    if (identical(LRpairSym_TypB, LRpairSym_TypA)) {   #-should same, otherwise, need preprocessing.
        LRpairSym <- LRpairSym_TypA
        crosstalk_Sym <- matrix(data = NA, nrow = nrow(LRpairSym)*2, ncol = 2)  #-initiated as double edges (maximum).
        ExpressedSco <- matrix(data = -100, nrow = nrow(LRpairSym)*2, ncol = 1) #-initiated as -100.
        NonSelfTalkSco <- matrix(data = -100, nrow = nrow(LRpairSym)*2, ncol = 1) #-initiated as -100.
        
        k <- 1   #-point to crosstalk_Sym.
        for (i in 1:nrow(LRpairSym)) {  #very fast.
            tf <- identical(LRpairSym[i, 1], LRpairSym[i, 2])
            
            if (!tf) {
                #--From TypA to TypB.
                crosstalk_Sym[k, 1] <- paste(c(LRpairSym[i, 1], "__TypA"), collapse = '')  #gene in TypA cell.
                crosstalk_Sym[k, 2] <- paste(c(LRpairSym[i, 2], "__TypB"), collapse = '')  #gene in TypB cell.
                
                #-compute non-self-talk score.
                NonSelfTalkSco[k] <- (NonSelfTalkSco_TypA$V1[i] + NonSelfTalkSco_TypB$V1[i]) / 2
                
                #-compute expressed score.
                ind_TypA <- which(same_rowname == LRpairSym[i, 1])   #-must have a single value.
                exp_TypA <- typeSpecific[[TypA_PEM_ind]][ind_TypA]
                if (is.nan(exp_TypA)) {
                    exp_TypA <- 0
                } else {
                    if (exp_TypA > 0) {
                        exp_TypA <- exp_TypA   #no change.
                        
                    } else {
                        exp_TypA <- 0
                        
                    }
                    
                }
                
                ind_TypB <- which(same_rowname == LRpairSym[i, 2])   #-must have a single value.
                exp_TypB <- typeSpecific[[TypB_PEM_ind]][ind_TypB]
                if (is.nan(exp_TypB)) {
                    exp_TypB <- 0
                    
                } else {
                    if (exp_TypB > 0) {
                        exp_TypB <- exp_TypB   #no change.
                        
                    } else {
                        exp_TypB <- 0
                        
                    }
                    
                }
                
                ExpressedSco[k] <- (exp_TypA + exp_TypB) / 2
                
                k <- k + 1
                
                
                #--From TypB to TypA.
                crosstalk_Sym[k, 1] <- paste(c(LRpairSym[i, 1], "__TypB"), collapse = '')  #gene in TypB cell.
                crosstalk_Sym[k, 2] <- paste(c(LRpairSym[i, 2], "__TypA"), collapse = '')  #gene in TypA cell.
                
                #-compute non-self-talk score.
                NonSelfTalkSco[k] <- (NonSelfTalkSco_TypB$V1[i] + NonSelfTalkSco_TypA$V1[i]) / 2   #-same as before.
                
                #-compute expressed score.
                ind_TypB <- which(same_rowname == LRpairSym[i, 1])   #-must have a single value.
                exp_TypB <- typeSpecific[[TypB_PEM_ind]][ind_TypB]
                if (is.nan(exp_TypB)) {
                    exp_TypB <- 0
                    
                } else {
                    if (exp_TypB > 0) {
                        exp_TypB <- exp_TypB   #no change.
                        
                    } else {
                        exp_TypB <- 0
                        
                    }
                    
                }
                
                ind_TypA <- which(same_rowname == LRpairSym[i, 2])   #-must have a single value.
                exp_TypA <- typeSpecific[[TypA_PEM_ind]][ind_TypA]
                if (is.nan(exp_TypA)) {
                    exp_TypA <- 0
                } else {
                    if (exp_TypA > 0) {
                        exp_TypA <- exp_TypA   #no change.
                        
                    } else {
                        exp_TypA <- 0
                        
                    }
                    
                }
                
                ExpressedSco[k] <- (exp_TypB + exp_TypA) / 2
                
                k <- k + 1
                
            } else {   #-two gene symbols are the same. No need to switch.
                #--From TypA to TypB.
                crosstalk_Sym[k, 1] <- paste(c(LRpairSym[i, 1], "__TypA"), collapse = '')  #gene in TypA cell.
                crosstalk_Sym[k, 2] <- paste(c(LRpairSym[i, 2], "__TypB"), collapse = '')  #gene in TypB cell.
                
                #-compute non-self-talk score.
                NonSelfTalkSco[k] <- (NonSelfTalkSco_TypA$V1[i] + NonSelfTalkSco_TypB$V1[i]) / 2
                
                #-compute expressed score.
                ind_TypA <- which(same_rowname == LRpairSym[i, 1])   #-must have a single value.
                exp_TypA <- typeSpecific[[TypA_PEM_ind]][ind_TypA]
                if (is.nan(exp_TypA)) {
                    exp_TypA <- 0
                } else {
                    if (exp_TypA > 0) {
                        exp_TypA <- exp_TypA   #no change.
                        
                    } else {
                        exp_TypA <- 0
                        
                    }
                    
                }
                
                ind_TypB <- which(same_rowname == LRpairSym[i, 2])   #-must have a single value.
                exp_TypB <- typeSpecific[[TypB_PEM_ind]][ind_TypB]
                if (is.nan(exp_TypB)) {
                    exp_TypB <- 0
                    
                } else {
                    if (exp_TypB > 0) {
                        exp_TypB <- exp_TypB   #no change.
                        
                    } else {
                        exp_TypB <- 0
                        
                    }
                    
                }
                
                ExpressedSco[k] <- (exp_TypA + exp_TypB) / 2
                
                k <- k + 1
                
            } #end of if-else.
            
        } #end of for.
        
    } #end of if.
    
    #-clean "crosstalk_Sym", "ExpressedSco" and "NonSelfTalkSco".
    ind <- which(is.na(crosstalk_Sym[, 1]))
    indind <- which(NonSelfTalkSco == -100)
    if (identical(ind, indind)) {  #if true, correct!
        if (length(indind) > 0) {
            crosstalk_Sym <- crosstalk_Sym[-indind,]
            ExpressedSco <- ExpressedSco[-indind,]
            NonSelfTalkSco <- NonSelfTalkSco[-indind,]

        }

    }
    
    #--Compute crosstalk score using normalized ExpressedSco and Non-self-talk score.
    #-normalize ExpressedSco.
    ExpressedSco_norm <- (ExpressedSco - min(ExpressedSco)) / (max(ExpressedSco) - min(ExpressedSco))
    
    #-normalize NonSelfTalkSco.
    NonSelfTalkSco_norm <- (NonSelfTalkSco - min(NonSelfTalkSco)) / (max(NonSelfTalkSco) - min(NonSelfTalkSco))
    
    #-compute crosstalk score.
    crosstalk_Sco <- ExpressedSco_norm * NonSelfTalkSco_norm
    
    Crosstalk_TypATypB_File <- paste(OutputPath, "/Crosstalk_TypATypB.RData", sep = "")
    save(LRpairSym_TypB, NonSelfTalkSco_TypB, LRpairSym_TypA, NonSelfTalkSco_TypA, crosstalk_Sym, ExpressedSco, NonSelfTalkSco, crosstalk_Sco, file = Crosstalk_TypATypB_File)

}


