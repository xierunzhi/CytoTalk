copyAnalysisFile <- function(BetaUpperLimit, InputPath, OutputPath) {
    
    #--Copy analysis files.
    BetaUpperLimit <- as.integer(BetaUpperLimit)
    
    betaValues <- seq(from = 1, to = BetaUpperLimit, by = 1)
    for (beta in betaValues) {
        
        omegaValues <- seq(from = 0.1, to = 1.5, by = 0.1)
        for (omega in omegaValues) {
            
            BtOmgFolderName <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta), "/bt", sprintf("%0.6f", beta), "_omg", omega, "/"), collapse = '')
            
            #--copy PCSF result analysis files.    
            str8_source <- paste(c(InputPath, "/deter_W4.R"), collapse = '')
            status_8 <- file.copy(str8_source, BtOmgFolderName, overwrite = TRUE)
            
        }  #-end of omega.
        
    }   #-end of beta.

}  #end of function.


runAnalysisFile <- function(BetaUpperLimit, OutputPath) {
    
    #-Run analysis files in each folder.
    library("doParallel")
    BetaUpperLimit <- as.integer(BetaUpperLimit)
    
    #-setup parallel environment.
    no_cores <- detectCores() - 2 #to be safe from any RStudio crashing, use two less cores.   
    cl <- makeCluster(no_cores, type="FORK")
    registerDoParallel(cl)
    
    #Sys.time()
    betaValues <- seq(from = 1, to = BetaUpperLimit, by = 1)
    resultStatus <- foreach (idx=1:length(betaValues)) %dopar% {  #less than 1min
        #for (idx in 1:length(betaValues)) {
        beta <- betaValues[idx]
        
        omegaValues <- seq(from = 0.1, to = 1.5, by = 0.1)
        for (omega in omegaValues) {
            
            BtOmgFolderName <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta), "/bt", sprintf("%0.6f", beta), "_omg", omega, "/"), collapse = '')
            
            #--run analysis files.
            setwd(BtOmgFolderName)
            source("deter_W4.R")
            #setwd("../../")  #no need to do this due to usage of absolute path.
            
        }  #-end of omega.
        
    }   #-end of beta.(dopar)
    stopCluster(cl)  #release resources.
    #Sys.time()
    
}  #end of function.


qualityCheck <- function(BetaUpperLimit, OutputPath) {
    
    #-Quality check for the generated PCSFs.
    BetaUpperLimit <- as.integer(BetaUpperLimit)
    
    betaValues <- seq(from = 1, to = BetaUpperLimit, by = 1)
    omegaValues <- seq(from = 0.1, to = 1.5, by = 0.1)
    
    qualityTable <- matrix(data = NA, nrow = length(betaValues)*length(omegaValues), ncol = 3)
    colnames(qualityTable) <- c("Beta", "Omega", "PCSFEdgeNum")
    k <- 1
    
    for (beta in betaValues) {
        
        omegaValues <- seq(from = 0.1, to = 1.5, by = 0.1)
        for (omega in omegaValues) {
            
            ResultFileName <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta), "/bt", sprintf("%0.6f", beta), "_omg", omega, "/pcsf_result4.RData"), collapse = '')
            
            #--combine analysis results.    
            load(ResultFileName)
            qualityTable[k, 1] <- beta
            qualityTable[k, 2] <- omega
            
            if (is.na(PCSF_edgeIndex[1])) {
                qualityTable[k, 3] <- 0
                
            } else {
                qualityTable[k, 3] <- length(PCSF_edgeIndex)
                
            }
            
            k <- k + 1
            
        }  #-end of omega.
        
    }   #-end of beta.
    
    #-clean data_1---remove beta values that make the number of edges in the PCSF above 2000, which is our empirical cutoff.
    rmRowInd_beta <- which(qualityTable[, 3] >= 2000)
    if (length(rmRowInd_beta) > 0) {
        qualityTable <- qualityTable[-rmRowInd_beta,]
        
    }
    
    #-clean data_2---remove omega values==0.1/0.2/0.3/0.4 due to very small number of PCSF edges.
    rmRowInd_omega <- which(qualityTable[, 2] < 0.5)
    qualityTable <- qualityTable[-rmRowInd_omega,]
    
    pcsf_finalResult4_File <- paste(OutputPath, "/pcsf_finalResult4.RData", sep = "")
    save(qualityTable, file = pcsf_finalResult4_File)
    
}  #end of function.


genSummaryPCSF <- function(BetaUpperLimit, InputPath, OutputPath) {
    
    copyAnalysisFile(BetaUpperLimit, InputPath, OutputPath)
    runAnalysisFile(BetaUpperLimit, OutputPath)
    qualityCheck(BetaUpperLimit, OutputPath)
    
}


