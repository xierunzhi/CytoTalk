genDiffOmgBt_Parallel <- function(BetaUpperLimit, InputPath, OutputPath) {
    
    #--Generate beta and omega folders for PCSF running.
    library("doParallel")
    
    ArtiEdge_File <- paste(OutputPath, "/ArtiEdge.RData", sep = "")
    load(ArtiEdge_File)
    
    IntegratedNet_TypATypB_ID_File <- paste(OutputPath, "/IntegratedNet_TypATypB_ID.RData", sep = "")
    load(IntegratedNet_TypATypB_ID_File)
    
    BetaUpperLimit <- as.integer(BetaUpperLimit)
    
    #-setup parallel environment.
    no_cores <- detectCores() - 2 #to be safe from any RStudio crashing, use two less cores.   
    cl <- makeCluster(no_cores, type="FORK")
    registerDoParallel(cl)
    #registerDoParallel(cores=14)  #-number of logical cores (current=14).
    #getDoParWorkers()
    
    #Sys.time()
    #-First beta range.
    betaValues <- seq(from = 1, to = BetaUpperLimit, by = 1)
    resultStatus <- foreach (idx=1:length(betaValues)) %dopar% {  # Much faster than Matlab: less than 1min.
        beta <- betaValues[idx]
        
        #-create "beta" outer folder.
        str1 <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta)), collapse = '')
        dir.create(str1, showWarnings = FALSE)
        
        #-generate prize txt file for this beta value.
        integratedNet_GenePrize <- beta * integratedNet_GenePrize_initial
        
        PrizeFileName <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta), "/IntegratedNet_nodePrize.txt"), collapse = '')
        write.table(integratedNet_GenePrize, PrizeFileName, quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)
        
        #-create "omega" inner folder.
        #-Second omega range.
        omegaValues <- seq(from = 0.1, to = 1.5, by = 0.1)
        for (omega in omegaValues) {
            
            str2 <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta), "/bt", sprintf("%0.6f", beta), "_omg", omega), collapse = '')
            dir.create(str2, showWarnings = FALSE)
            BtOmgFolderName <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta), "/bt", sprintf("%0.6f", beta), "_omg", omega, "/"), collapse = '')
            
            #--copy PCSF-input files.
            str3_source <- paste(c(OutputPath, "/IntegratedNet_edgeCost_common.txt"), collapse = '')
            str3_dest <- paste(c(BtOmgFolderName, "IntegratedNet_edgeCost.txt"), collapse = '')
            status_3 <- file.copy(str3_source, str3_dest, overwrite = TRUE)
            
            #--copy PCSF-generated files.
            str6_source <- paste(c(InputPath, "/gen_PCSF.py"), collapse = '')
            status_6 <- file.copy(str6_source, BtOmgFolderName, overwrite = TRUE)
            
            #--append different omega to the edge cost file in different folders.
            artiEdgeCost <- matrix(data = omega, nrow = nrow(artiEdge_id), ncol = 1)
            EdgeCostFileName <- paste(c(BtOmgFolderName, "IntegratedNet_edgeCost.txt"), collapse = '')
            write.table(artiEdgeCost, EdgeCostFileName, append = TRUE, quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)
            
        }  #-end of omega.
        
    }   #-end of beta.(dopar)
    stopCluster(cl)  #release resources.
    #Sys.time()
 
}


