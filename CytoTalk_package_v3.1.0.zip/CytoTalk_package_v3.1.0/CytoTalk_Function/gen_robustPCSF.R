recordPCSFBackground <- function(OutputPath) {
    
    #-Combine analysis results in each folder together to record Edge Background.
    pcsf_finalResult4_File <- paste(OutputPath, "/pcsf_finalResult4.RData", sep = "")
    load(pcsf_finalResult4_File)
    
    PCSF_edgeIndex_Tab <- c()
    for (i in 1:nrow(qualityTable)) {        #very fast.
        
        beta <- qualityTable[i, 1]
        omega <- qualityTable[i, 2]
        
        ResultFileName <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta), "/bt", sprintf("%0.6f", beta), "_omg", omega, "/pcsf_result4.RData"), collapse = '')
        #--combine analysis results.    
        load(ResultFileName)
        
        if (!is.na(PCSF_edgeIndex[1])) {
            PCSF_edgeIndex_Tab <- c(PCSF_edgeIndex_Tab, PCSF_edgeIndex)
            
        }
        
    }
    
    pcsf_finalResult4_2_File <- paste(OutputPath, "/pcsf_finalResult4_2.RData", sep = "")
    save(PCSF_edgeIndex_Tab, file = pcsf_finalResult4_2_File)

}  #end of function.


countEdgeOccurrence <- function(OutputPath) {
    
    #-Count the repeated times of each edge in each PCSF module.
    library("doParallel")
    
    pcsf_finalResult4_File <- paste(OutputPath, "/pcsf_finalResult4.RData", sep = "")
    load(pcsf_finalResult4_File)   #qualityTable
    
    pcsf_finalResult4_2_File <- paste(OutputPath, "/pcsf_finalResult4_2.RData", sep = "")
    load(pcsf_finalResult4_2_File)   #PCSF_edgeIndex_Tab
    
    #-setup parallel environment.
    no_cores <- detectCores() - 2 #to be safe from any RStudio crashing, use two less cores.   
    cl <- makeCluster(no_cores, type="FORK")
    registerDoParallel(cl)
    
    PCSF_edgeCount_fullList <- foreach (i=1:nrow(qualityTable)) %dopar% {                         #~20min
        #for (i in 1:nrow(qualityTable)) {
        
        beta <- qualityTable[i, 1]
        omega <- qualityTable[i, 2]
        
        ResultFileName <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta), "/bt", sprintf("%0.6f", beta), "_omg", omega, "/pcsf_result4.RData"), collapse = '')
        #--combine analysis results.    
        load(ResultFileName)
        
        if (!is.na(PCSF_edgeIndex[1])) {
            
            edgeCount <- matrix(data = 0L, nrow = length(PCSF_edgeIndex), ncol = 1)
            for (k in 1:length(PCSF_edgeIndex)) {
                edgeCount[k] <- length(which(PCSF_edgeIndex_Tab == PCSF_edgeIndex[k]))  #-at least one edge.
                
            }
            
            edgeCount #this is the returned value for "foreach".
            #PCSF_edgeCount_fullList[[i]] <- edgeCount
            #rm(edgeCount)
            
        } #end of if.
        
    } #end of dopar
    stopCluster(cl)  #release resources.
    
    pcsf_finalResult4_3_File <- paste(OutputPath, "/pcsf_finalResult4_3.RData", sep = "")
    save(PCSF_edgeCount_fullList, file = pcsf_finalResult4_3_File)

}  #end of function.


compRobustPvalue <- function(OutputPath) {
    
    #-Compute the ks-pvalue for each PCSF.
    library("doParallel")
    
    pcsf_finalResult4_File <- paste(OutputPath, "/pcsf_finalResult4.RData", sep = "")
    load(pcsf_finalResult4_File)   #qualityTable
    
    pcsf_finalResult4_3_File <- paste(OutputPath, "/pcsf_finalResult4_3.RData", sep = "")
    load(pcsf_finalResult4_3_File)   #PCSF_edgeCount_fullList
    
    #-setup parallel environment.
    no_cores <- detectCores() - 2 #to be safe from any RStudio crashing, use two less cores.   
    cl <- makeCluster(no_cores, type="FORK")
    registerDoParallel(cl)
    
    PCSF_edgeKSPval_fullList <- foreach (i = 1:nrow(qualityTable), .combine = 'rbind') %dopar% {          #~5min
        #for (i in 1:nrow(qualityTable)) {
        
        beta <- qualityTable[i, 1]
        omega <- qualityTable[i, 2]
        
        PCSF_edgeKSPval <- matrix(data = 1L, nrow = 1, ncol = 3)
        PCSF_edgeKSPval[1] <- beta
        PCSF_edgeKSPval[2] <- omega
        
        if (!is.null(PCSF_edgeCount_fullList[[i]])) {
            
            modifiedList <- PCSF_edgeCount_fullList
            #-remove itself.
            modifiedList <- modifiedList[-i]
            
            #-remove empty entries (no edges in the PCSF, only isolated root nodes after artificial edges removed).
            emptyInd <- which(sapply(modifiedList, is.null))
            modifiedList <- modifiedList[-emptyInd]
            
            #-compare to combined other parameter settings.
            other_edgeCount <- c()
            for (kk in 1:length(modifiedList)) {
                other_edgeCount <- c(other_edgeCount, modifiedList[[kk]])
                
            }
            
            #-using KS test.
            res <- ks.test(PCSF_edgeCount_fullList[[i]], other_edgeCount, alternative = "less")
            PCSF_edgeKSPval[3] <- res$p.value  #p-value is slightly different from Matlab result but their rankings are same.
            
        }  #end of if.
        
        PCSF_edgeKSPval  #this is the returned value for "foreach".
        
    }  #end of dopar
    stopCluster(cl)  #release resources.
    
    #-Select the PCSF with the minimum ks-pvalue.
    PCSF_edgeKSPval_fullList_sorted <- PCSF_edgeKSPval_fullList[order(PCSF_edgeKSPval_fullList[, 3], decreasing = FALSE),]
    beta_final <- PCSF_edgeKSPval_fullList_sorted[1, 1]
    omega_final <- PCSF_edgeKSPval_fullList_sorted[1, 2]
    
    pcsf_finalResult4_4_File <- paste(OutputPath, "/pcsf_finalResult4_4.RData", sep = "")
    save(PCSF_edgeKSPval_fullList, PCSF_edgeKSPval_fullList_sorted, beta_final, omega_final, file = pcsf_finalResult4_4_File)
    
}  #end of function.


genRobustPCSF <- function(OutputPath) {
    
    recordPCSFBackground(OutputPath)
    countEdgeOccurrence(OutputPath)
    compRobustPvalue(OutputPath)
    
}


