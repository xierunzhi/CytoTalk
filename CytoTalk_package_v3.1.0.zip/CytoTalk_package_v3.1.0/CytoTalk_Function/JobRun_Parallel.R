JobRunParallel <- function(OutputPath) {
  
  print("(5/7) Generating background PCSFs...(around 20 min)")
  
  library("doParallel")
  JobDir <- list.dirs(path = OutputPath)
  JobSubDir <- grep("_omg", JobDir, value = TRUE)
  
  
  #-setup parallel environment.
  no_cores <- detectCores() - 2 #to be safe from any RStudio crashing, use two less cores.   
  cl <- makeCluster(no_cores, type="FORK")
  registerDoParallel(cl)
  
  #Sys.time()
  resultStatus <- foreach (job_id=1:length(JobSubDir)) %dopar% {
    
    setwd(JobSubDir[job_id])
    system("python3 gen_PCSF.py") #should ensure the Python packages "pcst_fast", "numpy" and "datetime" have been installed.
    #setwd("../../")  #no need to do this due to usage of absolute path.
    
  }
  stopCluster(cl)  #release resources.
  #Sys.time()
  
}


