extractFinalPCSF <- function(OutputPath) {
    
    pcsf_finalResult4_4_File <- paste(OutputPath, "/pcsf_finalResult4_4.RData", sep = "")
    load(pcsf_finalResult4_4_File)
    
    ResultFileName <- paste(c(OutputPath, "/bt", sprintf("%0.6f", beta_final), "/bt", sprintf("%0.6f", beta_final), "_omg", omega_final, "/pcsf_result4.RData"), collapse = '')
    load(ResultFileName)
    
    Exp_cleaned_2_File <- paste(OutputPath, "/Exp_cleaned_2.RData", sep = "")
    load(Exp_cleaned_2_File)
    
    Exp_cleaned_4_File <- paste(OutputPath, "/Exp_cleaned_4.RData", sep = "")
    load(Exp_cleaned_4_File)
    
    IntegratedNet_TypATypB_ID_File <- paste(OutputPath, "/IntegratedNet_TypATypB_ID.RData", sep = "")
    load(IntegratedNet_TypATypB_ID_File)
    
    #---------Extract gene expression and gene cell type of resulting PCSF.
    PCSF_nodeSym <- unique(c(PCSF_edgeSym[, 1], PCSF_edgeSym[, 2]))
    PCSF_geneExp <- matrix(data = 0L, nrow = length(PCSF_nodeSym), ncol = 1)
    PCSF_geneCellType <- matrix(data = 0L, nrow = length(PCSF_nodeSym), ncol = 1)   #-"1" as TypA; "2" as TypB.
    for (i in 1:length(PCSF_nodeSym)) {
        if (substr(PCSF_nodeSym[i], nchar(PCSF_nodeSym[i])-5, nchar(PCSF_nodeSym[i])) == "__TypA") {
            
            PCSF_geneCellType[i] <- 1   #-"1" as TypA.
            ind <- which(rownames(TypAExp_rmRep_dmNew) == substr(PCSF_nodeSym[i], 1, nchar(PCSF_nodeSym[i])-6))  #-must have a single value.
            PCSF_geneExp[i] <- mean(as.matrix(TypAExp_rmRep_dmNew[ind,]))
            
        } else if (substr(PCSF_nodeSym[i], nchar(PCSF_nodeSym[i])-5, nchar(PCSF_nodeSym[i])) == "__TypB") {
            
            PCSF_geneCellType[i] <- 2   #-"2" as TypB.
            ind <- which(rownames(TypBExp_rmRep_dmNew) == substr(PCSF_nodeSym[i], 1, nchar(PCSF_nodeSym[i])-6))  #-must have a single value.
            PCSF_geneExp[i] <- mean(as.matrix(TypBExp_rmRep_dmNew[ind,]))
            
        }
        
    } #end of for.
    
    #---------Extract gene prize of resulting PCSF.
    PCSF_genePrize <- matrix(data = 0L, nrow = length(PCSF_nodeSym), ncol = 1)
    for (i in 1:length(PCSF_nodeSym)) {
        
        ind <- which(integratedNet_GeneSym == PCSF_nodeSym[i])  #-must have a single value.
        PCSF_genePrize[i] <- integratedNet_GenePrize_initial[ind]
        
    } #end of for.
    
    #---------Extract gene Real Name of resulting PCSF.
    PCSF_geneRealName <- matrix(data = NA, nrow = length(PCSF_nodeSym), ncol = 1)
    for (i in 1:length(PCSF_nodeSym)) {
        
        PCSF_geneRealName[i] <- substr(PCSF_nodeSym[i], 1, nchar(PCSF_nodeSym[i])-6)
        
    } #end of for.
    
    pcsf_resultCyto_File <- paste(OutputPath, "/pcsf_resultCyto.RData", sep = "")
    save(PCSF_nodeSym, PCSF_geneExp, PCSF_geneCellType, PCSF_edgeSym, PCSF_edgeIndex, PCSF_edgeCost, PCSF_edgeCellType, PCSF_genePrize, PCSF_geneRealName, crosstalk_edgeSym, file = pcsf_resultCyto_File)
    
}  #end of function.


writeCytoFile <- function(OutputPath) {
    
    #-----------------------------------------------Generate files for Cytoscape-----------------------------------------------------#
    #-format the gene symbol to replace "TypA" and "TypB" by real cell type names.
    pcsf_resultCyto_File <- paste(OutputPath, "/pcsf_resultCyto.RData", sep = "")
    load(pcsf_resultCyto_File)
    
    CellTypeName_File <- paste(OutputPath, "/CellTypeName.RData", sep = "")
    load(CellTypeName_File)
    
    for (p in 1:nrow(PCSF_edgeSym)) {
        for (q in 1:ncol(PCSF_edgeSym)) {
            
            if (substr(PCSF_edgeSym[p, q], nchar(PCSF_edgeSym[p, q])-3, nchar(PCSF_edgeSym[p, q])) == "TypA") {
                
                PCSF_edgeSym[p, q] <- paste(c(substr(PCSF_edgeSym[p, q], 1, nchar(PCSF_edgeSym[p, q])-4), CellTypeA), collapse = '')
                
            } else if (substr(PCSF_edgeSym[p, q], nchar(PCSF_edgeSym[p, q])-3, nchar(PCSF_edgeSym[p, q])) == "TypB") {
                
                PCSF_edgeSym[p, q] <- paste(c(substr(PCSF_edgeSym[p, q], 1, nchar(PCSF_edgeSym[p, q])-4), CellTypeB), collapse = '')
                
            }
            
        }
    }
    
    for (kk in 1:length(PCSF_nodeSym)) {
        
        if (substr(PCSF_nodeSym[kk], nchar(PCSF_nodeSym[kk])-3, nchar(PCSF_nodeSym[kk])) == "TypA") {
            
            PCSF_nodeSym[kk] <- paste(c(substr(PCSF_nodeSym[kk], 1, nchar(PCSF_nodeSym[kk])-4), CellTypeA), collapse = '')
            
        } else if (substr(PCSF_nodeSym[kk], nchar(PCSF_nodeSym[kk])-3, nchar(PCSF_nodeSym[kk])) == "TypB") {
            
            PCSF_nodeSym[kk] <- paste(c(substr(PCSF_nodeSym[kk], 1, nchar(PCSF_nodeSym[kk])-4), CellTypeB), collapse = '')
            
        }
        
    }
    
    #-create a folder for Cytoscape files.
    FolderName <- paste(c(OutputPath, "/IllustratePCSF/"), collapse = '')
    dir.create(FolderName, showWarnings = FALSE)
    
    # network topology file.
    addCol <- matrix(data = "pp", nrow = nrow(PCSF_edgeSym), ncol = 1)
    PCSF_edgeSym_modified1 <- cbind(PCSF_edgeSym[, 1], addCol, PCSF_edgeSym[, 2])
    PCSF_edgeSym_File <- paste(FolderName, "PCSF_edgeSym.sif", sep = "")
    write.table(PCSF_edgeSym_modified1, PCSF_edgeSym_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)
    
    # edge cost file.
    PCSF_edgeSym_attr <- matrix(data = NA, nrow = nrow(PCSF_edgeSym), ncol = 1)
    for (i in 1:nrow(PCSF_edgeSym)) {
        
        PCSF_edgeSym_attr[i] <- paste(c(PCSF_edgeSym[i, 1], "(pp)", PCSF_edgeSym[i, 2]), collapse = ' ')
    }
    PCSF_edgeSym_modified2 <- cbind(PCSF_edgeSym_attr, PCSF_edgeCost)
    colnames(PCSF_edgeSym_modified2) <- c("EdgeSym", "EdgeCost")
    PCSF_edgeCost_File <- paste(FolderName, "PCSF_edgeCost.txt", sep = "")
    write.table(PCSF_edgeSym_modified2, PCSF_edgeCost_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # edge cell type file.
    PCSF_edgeSym_modified3 <- cbind(PCSF_edgeSym_attr, PCSF_edgeCellType)
    colnames(PCSF_edgeSym_modified3) <- c("EdgeSym", "EdgeCellType")
    PCSF_edgeCellType_File <- paste(FolderName, "PCSF_edgeCellType.txt", sep = "")
    write.table(PCSF_edgeSym_modified3, PCSF_edgeCellType_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # gene node expression file.
    PCSF_nodeSym_modified1 <- cbind(PCSF_nodeSym, PCSF_geneExp)
    colnames(PCSF_nodeSym_modified1) <- c("GeneSym", "GeneExp")
    PCSF_geneExp_File <- paste(FolderName, "PCSF_geneExp.txt", sep = "")
    write.table(PCSF_nodeSym_modified1, PCSF_geneExp_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # gene node cell type file.
    PCSF_nodeSym_modified2 <- cbind(PCSF_nodeSym, PCSF_geneCellType)
    colnames(PCSF_nodeSym_modified2) <- c("GeneSym", "GeneCellType")
    PCSF_geneCellType_File <- paste(FolderName, "PCSF_geneCellType.txt", sep = "")
    write.table(PCSF_nodeSym_modified2, PCSF_geneCellType_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # gene node prize file.
    PCSF_nodeSym_modified3 <- cbind(PCSF_nodeSym, PCSF_genePrize)
    colnames(PCSF_nodeSym_modified3) <- c("GeneSym", "GenePrize")
    PCSF_genePrize_File <- paste(FolderName, "PCSF_genePrize.txt", sep = "")
    write.table(PCSF_nodeSym_modified3, PCSF_genePrize_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
    # gene node real name file.
    PCSF_nodeSym_modified4 <- cbind(PCSF_nodeSym, PCSF_geneRealName)
    colnames(PCSF_nodeSym_modified4) <- c("GeneSym", "GeneRealName")
    PCSF_geneRealName_File <- paste(FolderName, "PCSF_geneRealName.txt", sep = "")
    write.table(PCSF_nodeSym_modified4, PCSF_geneRealName_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)

}  #end of function.


writeCrosstalkFile <- function(OutputPath) {
    
    #---------------------Generate a txt file for identified crosstalk edges along with their original crosstalk scores-------------------#
    #-extract original crosstalk scores for identified crosstalk edges.
    pcsf_resultCyto_File <- paste(OutputPath, "/pcsf_resultCyto.RData", sep = "")
    load(pcsf_resultCyto_File)
    
    CellTypeName_File <- paste(OutputPath, "/CellTypeName.RData", sep = "")
    load(CellTypeName_File)
    
    Crosstalk_TypATypB_File <- paste(OutputPath, "/Crosstalk_TypATypB.RData", sep = "")
    load(Crosstalk_TypATypB_File)
    
    crosstalk_edgeSco_orig <- matrix(data = 0L, nrow = nrow(crosstalk_edgeSym), ncol = 1)
    for (i in 1:nrow(crosstalk_edgeSym)) {
        ind_11 <- which(crosstalk_Sym[, 1] == crosstalk_edgeSym[i, 1])
        ind_22 <- which(crosstalk_Sym[, 2] == crosstalk_edgeSym[i, 2])
        ind_final <- intersect(ind_11, ind_22)  #must have a single value.
        crosstalk_edgeSco_orig[i] <- crosstalk_Sco[ind_final]
        
    }
    
    #-format the crosstalk edge symbol to replace "TypA" and "TypB" by real cell type names.
    for (p in 1:nrow(crosstalk_edgeSym)) {
        for (q in 1:ncol(crosstalk_edgeSym)) {
            
            if (substr(crosstalk_edgeSym[p, q], nchar(crosstalk_edgeSym[p, q])-3, nchar(crosstalk_edgeSym[p, q])) == "TypA") {
                
                crosstalk_edgeSym[p, q] <- paste(c(substr(crosstalk_edgeSym[p, q], 1, nchar(crosstalk_edgeSym[p, q])-6), " (", CellTypeA, ")"), collapse = '')
                
            } else if (substr(crosstalk_edgeSym[p, q], nchar(crosstalk_edgeSym[p, q])-3, nchar(crosstalk_edgeSym[p, q])) == "TypB") {
                
                crosstalk_edgeSym[p, q] <- paste(c(substr(crosstalk_edgeSym[p, q], 1, nchar(crosstalk_edgeSym[p, q])-6), " (", CellTypeB, ")"), collapse = '')
                
            }
            
        }
    }
    
    #-sort the formatted crosstalk edges based on original crostalk score.
    crosstalk_edgeSymSorted <- crosstalk_edgeSym[order(crosstalk_edgeSco_orig, decreasing = TRUE),]
    crosstalk_edgeScoSorted_orig <- crosstalk_edgeSco_orig[order(crosstalk_edgeSco_orig, decreasing = TRUE),]
    
    crosstalk_edgeSymSorted <- cbind(crosstalk_edgeSymSorted, crosstalk_edgeScoSorted_orig)
    colnames(crosstalk_edgeSymSorted) <- c("Ligand", "Receptor", "CrosstalkScore")
    PCSF_CrosstalkEdge_File <- paste(OutputPath, "/IllustratePCSF/PCSF_CrosstalkEdge.txt", sep = "")
    write.table(crosstalk_edgeSymSorted, PCSF_CrosstalkEdge_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
    
}   #end of function.


genCytoFile <- function(OutputPath) {
    
    extractFinalPCSF(OutputPath)
    writeCytoFile(OutputPath)
    writeCrosstalkFile(OutputPath)
    
}


