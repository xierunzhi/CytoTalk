genRelevanceTypeA <- function(species, InputPath, OutputPath) {
    
    #------------Random walk with restart on TypA network.
    #-Compute normalized adjacency matrix.
    library("corpcor")
    
    MI_TypA_File <- paste(OutputPath, "/MI_TypA.RData", sep = "")
    load(MI_TypA_File)
    
    D_TypA <- matrix(data = 0L, nrow = nrow(MiMatrix_TypA), ncol = ncol(MiMatrix_TypA))
    MiMatrix_TypA_rowsum=rowSums(MiMatrix_TypA)
    for (k in 1:nrow(MiMatrix_TypA)) {
        
        D_TypA[k, k] <- MiMatrix_TypA_rowsum[k]
        
    }
    MiMatrix_TypA <- as.matrix(MiMatrix_TypA)
    print("------Calculating relevance coefficients for genes in cell type A...")
    nsq_D_TypA <- mpower(D_TypA, -0.5)  #6min/5200genes, nsq: negative square root.
    Wnorm_TypA <- nsq_D_TypA %*% MiMatrix_TypA %*% nsq_D_TypA  #-4min/5200genes.checked. Result in symmetric matrix.
    
    #-Extract all ligands or receptors as seeds for network propagation and construct prior information vector.
    if (species == "Human") {
        
        LigandReceptor_Human_File <- paste(InputPath, "/LigandReceptor_Human.txt", sep = "")
        LRpair <- read.table(LigandReceptor_Human_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
        
    }
    if (species == "Mouse") {
        
        LigandReceptor_Mouse_File <- paste(InputPath, "/LigandReceptor_Mouse.txt", sep = "")
        LRpair <- read.table(LigandReceptor_Mouse_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
        
    }
    LR_sym <- unique(c(LRpair$V1, LRpair$V2))
    Y_TypA <- vector()
    for (i in 1:length(RowNames_TypA)) {
        if (RowNames_TypA[i] %in% LR_sym) {
            Y_TypA[i] <- 1
            
        } else {
            Y_TypA[i] <- 0
            
        }
        
    } # end of for.
    
    #-Compute relevance value for each gene using random walk with restart procedure.
    iterNum <- 50   #enough to converge.
    alpha <- 0.9
    Relevance_TypA <- as.matrix(Y_TypA)   #-initialization.
    ReleDiff_TypA <- vector()
    for (i in 1:iterNum) {
        oldVec <- Relevance_TypA
        Relevance_TypA <- alpha * (Wnorm_TypA %*% Relevance_TypA) + (1 - alpha) * Y_TypA  #-checked each step.
        
        #-compute difference between consecutive runs using One-norm of a vector (the sum of absolute values).
        ReleDiff_TypA[i] <- norm(Relevance_TypA - oldVec, "O") / norm(oldVec, "O")
        
    }
    
    GeneRelevanceTypA_File <- paste(OutputPath, "/GeneRelevanceTypA.RData", sep = "")
    save(Wnorm_TypA, Y_TypA, alpha, Relevance_TypA, ReleDiff_TypA, file = GeneRelevanceTypA_File)

} #end of function.


genRelevanceTypeB <- function(species, InputPath, OutputPath) {
    
    #------------Random walk with restart on TypB network.
    #-Compute normalized adjacency matrix.
    library("corpcor")
    
    MI_TypB_File <- paste(OutputPath, "/MI_TypB.RData", sep = "")
    load(MI_TypB_File)
    
    D_TypB <- matrix(data = 0L, nrow = nrow(MiMatrix_TypB), ncol = ncol(MiMatrix_TypB))
    MiMatrix_TypB_rowsum=rowSums(MiMatrix_TypB)
    for (k in 1:nrow(MiMatrix_TypB)) {
        
        D_TypB[k, k] <- MiMatrix_TypB_rowsum[k]
        
    }
    MiMatrix_TypB <- as.matrix(MiMatrix_TypB)
    print("------Calculating relevance coefficients for genes in cell type B...")
    nsq_D_TypB <- mpower(D_TypB, -0.5)  #18min/7500genes, nsq: negative square root.
    Wnorm_TypB <- nsq_D_TypB %*% MiMatrix_TypB %*% nsq_D_TypB  #-10min/7500genes.checked. Result in symmetric matrix.
    
    #-Extract all ligands or receptors as seeds for network propagation and construct prior information vector.
    if (species == "Human") {
        
        LigandReceptor_Human_File <- paste(InputPath, "/LigandReceptor_Human.txt", sep = "")
        LRpair <- read.table(LigandReceptor_Human_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
        
    }
    if (species == "Mouse") {
        
        LigandReceptor_Mouse_File <- paste(InputPath, "/LigandReceptor_Mouse.txt", sep = "")
        LRpair <- read.table(LigandReceptor_Mouse_File, header = FALSE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
        
    }
    LR_sym <- unique(c(LRpair$V1, LRpair$V2))
    Y_TypB <- vector()
    for (i in 1:length(RowNames_TypB)) {
        if (RowNames_TypB[i] %in% LR_sym) {
            Y_TypB[i] <- 1
            
        } else {
            Y_TypB[i] <- 0
            
        }
        
    } # end of for.
    
    #-Compute relevance value for each gene using random walk with restart procedure.
    iterNum <- 50   #enough to converge.
    alpha <- 0.9
    Relevance_TypB <- as.matrix(Y_TypB)   #-initialization.
    ReleDiff_TypB <- vector()
    for (i in 1:iterNum) {
        oldVec <- Relevance_TypB
        Relevance_TypB <- alpha * (Wnorm_TypB %*% Relevance_TypB) + (1 - alpha) * Y_TypB  #-checked each step.
        
        #-compute difference between consecutive runs using One-norm of a vector (the sum of absolute values).
        ReleDiff_TypB[i] <- norm(Relevance_TypB - oldVec, "O") / norm(oldVec, "O")
        
    }
    
    GeneRelevanceTypB_File <- paste(OutputPath, "/GeneRelevanceTypB.RData", sep = "")
    save(Wnorm_TypB, Y_TypB, alpha, Relevance_TypB, ReleDiff_TypB, file = GeneRelevanceTypB_File)
    
}  #end of function.


compNodePrize_RWR <- function(species, InputPath, OutputPath) {
    
    genRelevanceTypeA(species, InputPath, OutputPath)
    genRelevanceTypeB(species, InputPath, OutputPath)
    print("------Relevance coefficient calculation done!")
    
}


