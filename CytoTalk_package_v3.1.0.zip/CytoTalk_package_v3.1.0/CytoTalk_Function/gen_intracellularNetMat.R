preprocess <- function(species, CellTypeA, CellTypeB, GeneFilterCutoff_A, GeneFilterCutoff_B, InputPath, OutputPath) {
  
  print("(1/7) Pre-processing the scRNA-seq data...(around 5 minutes)")
  
  #-Store two cell types.
  CellTypeName_File <- paste(OutputPath, "/CellTypeName.RData", sep = "")
  save(CellTypeA, CellTypeB, file = CellTypeName_File)
  
  #-1) Filter out lowly-expressed genes in cell type A.
  #Data cleaning-1.
  TypA_file <- paste(InputPath, "/scRNAseq_", CellTypeA, ".csv", sep = "")
  TypAExp_rmRep_dm0 <- read.csv(TypA_file) #now row names as first column.
  TypAExp_rmRep_dm <- TypAExp_rmRep_dm0[, -1] #remove the first column.
  rownames(TypAExp_rmRep_dm) <- TypAExp_rmRep_dm0[, 1]  #set first column as row names.
  rm(TypAExp_rmRep_dm0)
  
  filterGene_TypA <- c()  #initialize as an empty vector.
  cutoff_TypA <- floor(ncol(TypAExp_rmRep_dm) * GeneFilterCutoff_A);
  for (p in 1:nrow(TypAExp_rmRep_dm)) {
    
    if (length(which(TypAExp_rmRep_dm[p,] != 0)) <= cutoff_TypA) {
      filterGene_TypA <- c(filterGene_TypA, p)
      
    }
    
  }  #end of for.
  
  if (length(filterGene_TypA) > 0) {
    TypAExp_rmRep_dm <- TypAExp_rmRep_dm[-filterGene_TypA,]
    
  }
  
  #-2) Only keep protein-coding genes.
  #Data cleaning-2.
  if (identical(species, "Human")) {
    ProteinCodingFile <- paste(InputPath, "/ProteinCodingGenes_Human.txt", sep = "")
    protCodeGeneSym <- read.table(ProteinCodingFile, header = FALSE, stringsAsFactors = FALSE)
    protCodeGeneSym <- protCodeGeneSym$V1
    
  } else if (identical(species, "Mouse")) {
    ProteinCodingFile <- paste(InputPath, "/ProteinCodingGenes_Mouse.txt", sep = "")
    protCodeGeneSym <- read.table(ProteinCodingFile, header = FALSE, stringsAsFactors = FALSE)
    protCodeGeneSym <- protCodeGeneSym$V1
    
  }
  
  pseudoInd_TypA <- c()  #initialize as an empty vector.
  for (i in 1:nrow(TypAExp_rmRep_dm)) {
    isProtCode <- rownames(TypAExp_rmRep_dm)[i] %in% protCodeGeneSym
    if (!isProtCode) {
      pseudoInd_TypA <- c(pseudoInd_TypA, i)
      
    }
    
  } #end of for.
  
  if (length(pseudoInd_TypA) > 0) {
    TypAExp_rmRep_dm <- TypAExp_rmRep_dm[-pseudoInd_TypA,]
    
  }
  TypAExp_rmRep_dmNew <- TypAExp_rmRep_dm
  Exp_cleaned_2_File <- paste(OutputPath, "/Exp_cleaned_2.RData", sep = "")
  save(TypAExp_rmRep_dmNew, file = Exp_cleaned_2_File)
  
  
  #-3) Filter out lowly-expressed genes in cell type B.
  #Data cleaning-1.
  TypB_file <- paste(InputPath, "/scRNAseq_", CellTypeB, ".csv", sep = "")
  TypBExp_rmRep_dm0 <- read.csv(TypB_file) #now row names as first column.
  TypBExp_rmRep_dm <- TypBExp_rmRep_dm0[, -1] #remove the first column.
  rownames(TypBExp_rmRep_dm) <- TypBExp_rmRep_dm0[, 1]  #set first column as row names.
  rm(TypBExp_rmRep_dm0)
  
  filterGene_TypB <- c()  #initialize as an empty vector.
  cutoff_TypB <- floor(ncol(TypBExp_rmRep_dm) * GeneFilterCutoff_B);
  for (p in 1:nrow(TypBExp_rmRep_dm)) {
    
    if (length(which(TypBExp_rmRep_dm[p,] != 0)) <= cutoff_TypB) {
      filterGene_TypB <- c(filterGene_TypB, p)
      
    }
    
  }  #end of for.
  
  if (length(filterGene_TypB) > 0) {
    TypBExp_rmRep_dm <- TypBExp_rmRep_dm[-filterGene_TypB,]
    
  }
  
  #-4) Only keep protein-coding genes.
  #Data cleaning-2.
  pseudoInd_TypB <- c()  #initialize as an empty vector.
  for (i in 1:nrow(TypBExp_rmRep_dm)) {
    isProtCode <- rownames(TypBExp_rmRep_dm)[i] %in% protCodeGeneSym
    if (!isProtCode) {
      pseudoInd_TypB <- c(pseudoInd_TypB, i)
      
    }
    
  } #end of for.
  
  if (length(pseudoInd_TypB) > 0) {
    TypBExp_rmRep_dm <- TypBExp_rmRep_dm[-pseudoInd_TypB,]
    
  }
  TypBExp_rmRep_dmNew <- TypBExp_rmRep_dm
  Exp_cleaned_4_File <- paste(OutputPath, "/Exp_cleaned_4.RData", sep = "")
  save(TypBExp_rmRep_dmNew, file = Exp_cleaned_4_File)
  
  
  #--Export gene expression into csv to compute
  #mutual information-based indirect edge-filtered network matrices.
  TypAExp_rmRepGf_dm_File <- paste(OutputPath, "/TypAExp_rmRepGf_dm.csv", sep = "")
  TypBExp_rmRepGf_dm_File <- paste(OutputPath, "/TypBExp_rmRepGf_dm.csv", sep = "")
  write.table(TypAExp_rmRep_dmNew, TypAExp_rmRepGf_dm_File, quote = FALSE, sep = ",")
  write.table(TypBExp_rmRep_dmNew, TypBExp_rmRepGf_dm_File, quote = FALSE, sep = ",")

}


