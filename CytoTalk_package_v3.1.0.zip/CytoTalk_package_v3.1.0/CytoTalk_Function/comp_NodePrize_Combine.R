compNodePrize_Combine <- function(OutputPath) {
    
    CellTypeName_File <- paste(OutputPath, "/CellTypeName.RData", sep = "")
    load(CellTypeName_File)
    
    GeneCellTypeSpecific_File <- paste(OutputPath, "/GeneCellTypeSpecific.RData", sep = "")
    load(GeneCellTypeSpecific_File)
    
    MI_TypA_File <- paste(OutputPath, "/MI_TypA.RData", sep = "")
    load(MI_TypA_File)
    
    GeneRelevanceTypA_File <- paste(OutputPath, "/GeneRelevanceTypA.RData", sep = "")
    load(GeneRelevanceTypA_File)
    
    MI_TypB_File <- paste(OutputPath, "/MI_TypB.RData", sep = "")
    load(MI_TypB_File)
    
    GeneRelevanceTypB_File <- paste(OutputPath, "/GeneRelevanceTypB.RData", sep = "")
    load(GeneRelevanceTypB_File)
    
    for (s in 1:length(allExpFile)) {
        if (grepl(CellTypeA, allExpFile[s], fixed = TRUE)) {
            TypA_ind <- s
            
        }
        if (grepl(CellTypeB, allExpFile[s], fixed = TRUE)) {
            TypB_ind <- s
            
        }
        
    }
    
    TypeSpecific_TypA <- matrix(data = 0, nrow = length(RowNames_TypA), ncol = 1)
    for (p in 1:length(RowNames_TypA)) {
        ind <- which(same_rowname == RowNames_TypA[p])  #very fast.
        TypeSpecific_TypA[p] <- typeSpecific[[TypA_ind]][ind]  #-must have single value.
        
    }
    
    TypeSpecific_TypB <- matrix(data = 0, nrow = length(RowNames_TypB), ncol = 1)
    for (q in 1:length(RowNames_TypB)) {
        ind <- which(same_rowname == RowNames_TypB[q])  #very fast.
        TypeSpecific_TypB[q] <- typeSpecific[[TypB_ind]][ind]  #-must have single value.
        
    }
    
    #-set under zero to 0 to make gene prize nonnegative.
    underExpressInd_TypA <- which(TypeSpecific_TypA < 0)
    TypeSpecific_TypA[underExpressInd_TypA] <- 0
    underExpressInd_TypB <- which(TypeSpecific_TypB < 0)
    TypeSpecific_TypB[underExpressInd_TypB] <- 0
    
    GenePrize_TypA <- Relevance_TypA * TypeSpecific_TypA
    GenePrize_TypB <- Relevance_TypB * TypeSpecific_TypB
    
    GeneNodePrize_File <- paste(OutputPath, "/GeneNodePrize.RData", sep = "")
    save(RowNames_TypA, RowNames_TypB, TypeSpecific_TypA, TypeSpecific_TypB, Relevance_TypA, Relevance_TypB, GenePrize_TypA, GenePrize_TypB, file = GeneNodePrize_File)
    
}


