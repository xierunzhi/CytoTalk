compArtiNet <- function(OutputPath) {
  
  #-Add all gene-related artificial edges.
  MI_topNet_TypATypB_File <- paste(OutputPath, "/MI_topNet_TypATypB.RData", sep = "")
  load(MI_topNet_TypATypB_File)
  
  artiConnectGene_id <- unique(c(MiList_genePair_TypATypB[, 1], MiList_genePair_TypATypB[, 2]))
  
  artiNodePrize <- 1  #-This value is irrelavant to the result.
  artiNodeSym <- "artiNode"
  artiNode_id <- length(MiList_geneSym_TypATypB) + 1
  artiConnectGene_id <- as.matrix(sort(artiConnectGene_id))
  artiEdge_id <- cbind(matrix(data = artiNode_id, nrow = nrow(artiConnectGene_id), ncol = 1), artiConnectGene_id)
  
  ArtiEdge_File <- paste(OutputPath, "/ArtiEdge.RData", sep = "")
  save(artiNodePrize, artiNodeSym, artiNode_id, artiEdge_id, file = ArtiEdge_File)
  
}


