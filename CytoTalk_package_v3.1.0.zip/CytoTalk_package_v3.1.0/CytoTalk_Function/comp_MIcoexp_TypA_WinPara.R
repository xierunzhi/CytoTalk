compMI_TypeA <- function(OutputPath) {
  
  print("(2/7) Computing mutual information for cell type A...(around 2 hours)")
  
  library(infotheo)
  library(doParallel)
  
  #load Tumo expression matrix
  TypAExp_rmRepGf_dm_File <- paste(OutputPath, "/TypAExp_rmRepGf_dm.csv", sep = "")
  TumoExp <- read.csv(TypAExp_rmRepGf_dm_File)
  
  TumoExp <- t(TumoExp)
  TumoExp_discrete <- discretize(TumoExp)
  
  #-setup parallel environment.
  no_cores <- detectCores() - 2 #to be safe from any RStudio crashing, use two less cores.   
  cl <- makeCluster(no_cores, type="FORK")
  registerDoParallel(cl)
  #registerDoParallel(cores=14)  #-number of logical cores (current=14).
  #getDoParWorkers()
  
  #calculate mutual information matrix.
  #Sys.time()
  MImatrix <- foreach (i = 1:ncol(TumoExp_discrete), .packages = c('infotheo', 'doParallel'), .combine = 'rbind') %dopar% { 
    
    #---------progress bar-------------#
    #cat("Gene:", i, "\n");
    #----------------------------------#
    
    foreach (j = 1:ncol(TumoExp_discrete), .combine = 'c') %do% {
      
      mutinformation(TumoExp_discrete[, i], TumoExp_discrete[, j], method = "mm") 
      
    }
  }
  stopCluster(cl)  #release resources.
  #Sys.time()
  
  MutualInfo_TypA_Para_File <- paste(OutputPath, "/MutualInfo_TypA_Para.txt", sep = "")
  write.table(MImatrix, MutualInfo_TypA_Para_File, quote = FALSE)
  #Sys.time()
  
}


