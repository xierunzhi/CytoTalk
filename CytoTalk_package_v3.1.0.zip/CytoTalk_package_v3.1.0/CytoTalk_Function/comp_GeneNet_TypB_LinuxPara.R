compGeneNet_TypeB <- function(OutputPath) {
  
  print("(3/7) Removing indirect edges for cell type B...(around 5 min)")
  
  library(doParallel)
  #-setup parallel environment.
  no_cores <- detectCores() - 2 #to be safe from any RStudio crashing, use two less cores.
  Sys.setenv("OMP_NUM_THREADS" = no_cores)
  
  #load Macr mutual information matrix.
  MutualInfo_TypB_Para_File <- paste(OutputPath, "/MutualInfo_TypB_Para.txt", sep = "")
  MIadj_Macr <- read.table(MutualInfo_TypB_Para_File, header = TRUE, sep = " ") #-checked.
  
  #set diagonal values to zeros to avoid self-cycles.
  totalGene <- 1:nrow(MIadj_Macr)
  for (i in totalGene) {
    #---------progress bar-------------#
    #cat("Gene:", i, "\n"); #Very fast.
    #----------------------------------#
    
    MIadj_Macr[i,i] <- 0
    
  }
  
  #remove indirect edges.(should set environment variable: export OMP_NUM_THREADS=n)
  library(parmigene)
  #Sys.time()
  MIadj_Macr <- as.matrix(MIadj_Macr)
  GN_Macr <- aracne.m(MIadj_Macr, 0.15) 
  #Sys.time()
  
  IntracellularNetwork_TypeB_File <- paste(OutputPath, "/IntracellularNetwork_TypeB.txt", sep = "")
  write.table(GN_Macr, IntracellularNetwork_TypeB_File, quote = FALSE) 
  #Sys.time()

}


