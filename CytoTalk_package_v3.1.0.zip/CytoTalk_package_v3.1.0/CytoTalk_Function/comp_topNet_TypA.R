compNetCostPrize_TypeA <- function(OutputPath) {
    
    #--------------------Generate edge costs of TypA for PCSF.
    MI_TypA_File <- paste(OutputPath, "/MI_TypA.RData", sep = "")
    load(MI_TypA_File)
    
    mu <- mean(MiList_value_TypA)
    sigma <- sd(MiList_value_TypA)
    MiList_value_TypA <- (MiList_value_TypA - mu) / sigma
    
    GeneInEdge <- unique(c(MiList_genePair_TypA[, 1], MiList_genePair_TypA[, 2]))
    if (length(GeneInEdge) == length(RowNames_TypA)) {   #-should hold, if not, matrix to list part is wrong.
        MiList_geneSym_TypA <- matrix(data =NA, nrow = length(RowNames_TypA), ncol = 1)
        
        for (pp in 1:length(RowNames_TypA)) {
            MiList_geneSym_TypA[pp] <- paste(c(RowNames_TypA[pp], "__TypA"), collapse = '')
            
        }
        
    }
    
    #--------------------Generate node prize of TypA for PCSF.
    GeneNodePrize_File <- paste(OutputPath, "/GeneNodePrize.RData", sep = "")
    load(GeneNodePrize_File)
    
    MiList_genePrize_TypA <- matrix(data = 0, nrow = length(MiList_geneSym_TypA), ncol = 1)
    for (i in 1:length(MiList_geneSym_TypA)) {
        ind <- which(RowNames_TypA == substr(MiList_geneSym_TypA[i], 1, nchar(MiList_geneSym_TypA[i])-6))  #-extract original gene symbol without "__TypA".
        MiList_genePrize_TypA[i] <- GenePrize_TypA[ind]
        
    }
    
    MI_topNet_TypA_File <- paste(OutputPath, "/MI_topNet_TypA.RData", sep = "")
    save(MiList_genePair_TypA, MiList_value_TypA, MiList_geneSym_TypA, MiList_genePrize_TypA, file = MI_topNet_TypA_File)
    
}


