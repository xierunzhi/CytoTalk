writeIntegratedNet <- function(OutputPath) {
  
  #-------------------Write edgeID and edge costs and node prizes (later) of integrated network to txt file for identifying PCSF using Python.
  IntegratedNet_TypATypB_ID_File <- paste(OutputPath, "/IntegratedNet_TypATypB_ID.RData", sep = "")
  load(IntegratedNet_TypATypB_ID_File)
  
  IntegratedNet_edge_File <- paste(OutputPath, "/IntegratedNet_edge.txt", sep = "")
  write.table(integratedNet_EdgeID, IntegratedNet_edge_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)  #this is tab-delimited format for importing to Python.
  
  IntegratedNet_edgeCost_common_File <- paste(OutputPath, "/IntegratedNet_edgeCost_common.txt", sep = "")
  write.table(integratedNet_EdgeCost_common, IntegratedNet_edgeCost_common_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)
  
  RootNode_File <- paste(OutputPath, "/RootNode.txt", sep = "")
  write.table(length(integratedNet_GeneSym) - 1, RootNode_File, quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)

}


