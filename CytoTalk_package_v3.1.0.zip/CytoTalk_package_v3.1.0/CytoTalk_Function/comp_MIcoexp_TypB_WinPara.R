compMI_TypeB <- function(OutputPath) {
  
  print("(2/7) Computing mutual information for cell type B...(around 2 hours)")
  
  library(infotheo)
  library(doParallel)
  
  #load Macr expression matrix
  TypBExp_rmRepGf_dm_File <- paste(OutputPath, "/TypBExp_rmRepGf_dm.csv", sep = "")
  MacrExp <- read.csv(TypBExp_rmRepGf_dm_File)
  
  MacrExp <- t(MacrExp)
  MacrExp_discrete <- discretize(MacrExp)
  
  #-setup parallel environment.
  no_cores <- detectCores() - 2 #to be safe from any RStudio crashing, use two less cores.   
  cl <- makeCluster(no_cores, type="FORK")
  registerDoParallel(cl)
  #registerDoParallel(cores=14)  #-number of logical cores (current=14).
  #getDoParWorkers()
  
  #calculate mutual information matrix.
  #Sys.time()
  MImatrix <- foreach (i = 1:ncol(MacrExp_discrete), .packages = c('infotheo', 'doParallel'), .combine = 'rbind') %dopar% { 
    
    #---------progress bar-------------#
    #cat("Gene:", i, "\n");
    #----------------------------------#
    
    foreach (j = 1:ncol(MacrExp_discrete), .combine = 'c') %do% {
      
      mutinformation(MacrExp_discrete[, i], MacrExp_discrete[, j], method = "mm") 
      
    }
  }
  stopCluster(cl)  #release resources.
  #Sys.time()
  
  MutualInfo_TypB_Para_File <- paste(OutputPath, "/MutualInfo_TypB_Para.txt", sep = "")
  write.table(MImatrix, MutualInfo_TypB_Para_File, quote = FALSE)
  #Sys.time()
  
}


