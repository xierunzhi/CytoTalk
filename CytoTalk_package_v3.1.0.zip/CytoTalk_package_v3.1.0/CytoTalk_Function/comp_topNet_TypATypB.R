compNetCostPrize_TypeATypeB <- function(OutputPath) {
    
    #--------------------Generate edge costs of TypB for PCSF.
    MI_TypB_File <- paste(OutputPath, "/MI_TypB.RData", sep = "")
    load(MI_TypB_File)
    
    mu <- mean(MiList_value_TypB)
    sigma <- sd(MiList_value_TypB)
    MiList_value_TypB <- (MiList_value_TypB - mu) / sigma
    
    GeneInEdge <- unique(c(MiList_genePair_TypB[, 1], MiList_genePair_TypB[, 2]))
    if (length(GeneInEdge) == length(RowNames_TypB)) {   #-should hold, if not, matrix to list part is wrong.
        MiList_geneSym_TypB <- matrix(data =NA, nrow = length(RowNames_TypB), ncol = 1)
        
        for (pp in 1:length(RowNames_TypB)) {
            MiList_geneSym_TypB[pp] <- paste(c(RowNames_TypB[pp], "__TypB"), collapse = '')
            
        }
        
    }
    
    MI_topNet_TypA_File <- paste(OutputPath, "/MI_topNet_TypA.RData", sep = "")
    load(MI_topNet_TypA_File)
    
    MiList_geneSym_TypATypB <- rbind(MiList_geneSym_TypA, MiList_geneSym_TypB)
    MiList_genePair_TypB_new <- MiList_genePair_TypB + length(MiList_geneSym_TypA)
    MiList_genePair_TypATypB <- rbind(MiList_genePair_TypA, MiList_genePair_TypB_new)
    MiList_value_TypATypB <- c(MiList_value_TypA, MiList_value_TypB)
    
    #--------------------Generate node prize of TypB for PCSF.
    GeneNodePrize_File <- paste(OutputPath, "/GeneNodePrize.RData", sep = "")
    load(GeneNodePrize_File)
    
    MiList_genePrize_TypB <- matrix(data = 0, nrow = length(MiList_geneSym_TypB), ncol = 1)
    for (i in 1:length(MiList_geneSym_TypB)) {
        ind <- which(RowNames_TypB == substr(MiList_geneSym_TypB[i], 1, nchar(MiList_geneSym_TypB[i])-6))  #-extract original gene symbol without "__TypB".
        MiList_genePrize_TypB[i] <- GenePrize_TypB[ind]
        
    }
    MI_topNet_TypB_File <- paste(OutputPath, "/MI_topNet_TypB.RData", sep = "")
    save(MiList_genePair_TypB, MiList_value_TypB, MiList_geneSym_TypB, MiList_genePair_TypB_new, MiList_genePrize_TypB, file = MI_topNet_TypB_File)
    
    
    MiList_genePrize_TypATypB <- rbind(MiList_genePrize_TypA, MiList_genePrize_TypB)
    
    MI_topNet_TypATypB_File <- paste(OutputPath, "/MI_topNet_TypATypB.RData", sep = "")
    save(MiList_geneSym_TypATypB, MiList_genePair_TypATypB, MiList_value_TypATypB, MiList_genePrize_TypATypB, file = MI_topNet_TypATypB_File)
    
}


