compCrosstalkNet <- function(OutputPath) {
    
    Crosstalk_TypATypB_File <- paste(OutputPath, "/Crosstalk_TypATypB.RData", sep = "")
    MI_topNet_TypATypB_File <- paste(OutputPath, "/MI_topNet_TypATypB.RData", sep = "")
    load(Crosstalk_TypATypB_File)
    load(MI_topNet_TypATypB_File)
    
    crosstalkNet_Sym <- matrix(data = NA, nrow = nrow(crosstalk_Sym), ncol = 2)  #-initiated as maximum.
    crosstalkNet_id <- matrix(data = 0L, nrow = nrow(crosstalk_Sym), ncol = 2)
    crosstalkNet_Sco <- matrix(data = -100, nrow = nrow(crosstalk_Sym), ncol = 1) #-initiated as -100.
    
    k <- 1    #-point to crosstalkNet_Sym.
    for (i in 1:nrow(crosstalk_Sym)) {
        if (crosstalk_Sym[i, 1] %in% MiList_geneSym_TypATypB & crosstalk_Sym[i, 2] %in% MiList_geneSym_TypATypB) {
            crosstalkNet_Sym[k, 1] <- crosstalk_Sym[i, 1]
            crosstalkNet_Sym[k, 2] <- crosstalk_Sym[i, 2]
            
            crosstalkNet_id[k, 1] <- which(MiList_geneSym_TypATypB == crosstalkNet_Sym[k, 1])
            crosstalkNet_id[k, 2] <- which(MiList_geneSym_TypATypB == crosstalkNet_Sym[k, 2])
            
            crosstalkNet_Sco[k] <- crosstalk_Sco[i]
            
            k <- k + 1
            
        }
        
    } #end of for.
    
    #-clean "crosstalkNet_Sym" and "crosstalkNet_Sco".
    ind <- which(is.na(crosstalkNet_Sym[, 1]))
    indind <- which(crosstalkNet_Sco == -100)
    if (identical(ind, indind)) {  #if true, correct!
        if (length(indind) > 0) {
            crosstalkNet_Sym <- crosstalkNet_Sym[-indind,]
            crosstalkNet_id <- crosstalkNet_id[-indind,]
            crosstalkNet_Sco <- crosstalkNet_Sco[-indind]

        }
        
    }
    
    #--Remove zero crosstalk edges.
    negInd <- which(crosstalkNet_Sco <= 0)
    if (length(negInd) > 0) {
        crosstalkNet_Sym <- crosstalkNet_Sym[-negInd,]
        crosstalkNet_id <- crosstalkNet_id[-negInd,]
        crosstalkNet_Sco <- crosstalkNet_Sco[-negInd]

    }
    
    #-edge weight normalized using zscore.
    mu <- mean(crosstalkNet_Sco)
    sigma <- sd(crosstalkNet_Sco)
    crosstalkNet_Sco <- (crosstalkNet_Sco - mu) / sigma
    
    CrosstalkNet_TypATypB_File <- paste(OutputPath, "/CrosstalkNet_TypATypB.RData", sep = "")
    save(crosstalkNet_Sym, crosstalkNet_Sco, crosstalkNet_id, file = CrosstalkNet_TypATypB_File)
    
}


