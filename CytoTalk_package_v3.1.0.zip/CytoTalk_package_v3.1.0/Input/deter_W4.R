#---Import edge indices and convert them to edge symbols.
rm(list = ls())
info <- file.info("PCSF_Edge.txt")
if (info$size == 0) {
    
    PCSF_edgeIndex <- NA
    save(PCSF_edgeIndex, file = "pcsf_result4.RData")

} else {  #else_1
    
    PCSF_edgeIndex <- read.table("PCSF_Edge.txt", header = FALSE, stringsAsFactors = FALSE)
    PCSF_edgeIndex <- as.matrix(PCSF_edgeIndex)
    
    PCSF_nodeIndex <- read.table("PCSF_Node.txt", header = FALSE, stringsAsFactors = FALSE)
    PCSF_nodeIndex <- as.matrix(PCSF_nodeIndex)
    
    load("../../IntegratedNet_TypATypB_ID.RData")
    PCSF_edgeSym <- matrix(data = NA, nrow = length(PCSF_edgeIndex), ncol = 2)
    for (i in 1:length(PCSF_edgeIndex)) {
        PCSF_edgeSym[i, 1] <- integratedNet_GeneSym[integratedNet_EdgeID[PCSF_edgeIndex[i]+1, 1]+1] #-Note:edgeIndex and nodeIndex both from 0 in Python.
        PCSF_edgeSym[i, 2] <- integratedNet_GeneSym[integratedNet_EdgeID[PCSF_edgeIndex[i]+1, 2]+1]
        
    }
    PCSF_edge2nodeSym <- unique(c(PCSF_edgeSym[, 1], PCSF_edgeSym[, 2]))  #-now is still a tree.
    PCSF_nodeSym <- integratedNet_GeneSym[PCSF_nodeIndex+1]
    if (identical(sort(PCSF_edge2nodeSym), sort(PCSF_nodeSym))) {
        correctFlag <- 1
        
    } else {
        correctFlag <- 0
        
    }
    
    
    #---Remove 'artiNode'-associated edges.
    ind <- which(PCSF_edgeSym == "artiNode", arr.ind = TRUE)
    removeInd <- ind[, 1]
    RootInd <- cbind(as.matrix(removeInd), matrix(data = 2L, nrow = length(removeInd), ncol = 1))
    Root <- PCSF_edgeSym[RootInd]
    PCSF_edgeIndex <- as.matrix(PCSF_edgeIndex[-removeInd,])
    PCSF_edgeSym <- as.matrix(PCSF_edgeSym[-removeInd,])
    if (length(PCSF_edgeIndex) == 0) {
        
        PCSF_edgeIndex <- NA
        save(PCSF_edgeIndex, file = "pcsf_result4.RData")

    } else {   #else_2
        
        if (length(PCSF_edgeIndex) == 1) {
            PCSF_edgeSym <- t(PCSF_edgeSym)
            
        }
        PCSF_edgeCost <- as.matrix(integratedNet_EdgeCost_common[PCSF_edgeIndex+1])  #-this already exclude artifical edge costs.
        nEdge <- nrow(PCSF_edgeSym)
        
        
        #---Remove 'artiNode' from PCSF_nodeSym.
        ind <- which(PCSF_nodeSym == "artiNode")
        PCSF_nodeSym <- as.matrix(PCSF_nodeSym[-ind])
        PCSF_nodeIndex <- as.matrix(PCSF_nodeIndex[-ind])
        
        
        #-----------Extract crosstalk edges in the forest.
        PCSF_edgeCellType <- matrix(data = 0, nrow = nrow(PCSF_edgeSym), ncol = 1)
        for (i in 1:nrow(PCSF_edgeSym)) {
            if (grepl("__TypA", PCSF_edgeSym[i, 1], fixed = TRUE) & grepl("__TypA", PCSF_edgeSym[i, 2], fixed = TRUE)) {
                PCSF_edgeCellType[i] <- 1  #-"1" as TypA.
                
            } else if (grepl("__TypB", PCSF_edgeSym[i, 1], fixed = TRUE) & grepl("__TypB", PCSF_edgeSym[i, 2], fixed = TRUE)) {
                PCSF_edgeCellType[i] <- 2  #-"2" as TypB.
                
            } else {
                PCSF_edgeCellType[i] <- 3  #-"3" as Crosstalk.
                
            }
            
        } #end of for.
        crosstalkInd <- which(PCSF_edgeCellType == 3)
        crosstalk_edgeSym <- PCSF_edgeSym[crosstalkInd,]
        crosstalk_edgeNum <- nrow(crosstalk_edgeSym)
        save(PCSF_edgeIndex, PCSF_nodeIndex, PCSF_edgeSym, PCSF_nodeSym, correctFlag, PCSF_edgeCost, Root, nEdge, crosstalk_edgeSym, crosstalk_edgeNum, PCSF_edgeCellType, file = "pcsf_result4.RData")
        
    }  #end of else_2.
    
} #end of else_1.


